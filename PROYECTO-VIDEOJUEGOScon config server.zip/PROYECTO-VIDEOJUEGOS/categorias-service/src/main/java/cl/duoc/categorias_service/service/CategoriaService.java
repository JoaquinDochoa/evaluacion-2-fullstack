package cl.duoc.categorias_service.service;

import cl.duoc.categorias_service.model.Categoria;
import cl.duoc.categorias_service.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoriaService {

    @Autowired
    private CategoriaRepository repository;

    public List<Categoria> findAll(){
        return repository.findAll();
    }

    public Categoria findById(Long id){
        return repository.findById(id).orElse(null);
    }

    public Categoria save(Categoria categoria){
        return repository.save(categoria);
    }

    public void delete(Long id){
        repository.deleteById(id);
    }

    public Categoria update(Long id, Categoria categoria){

        Optional<Categoria> categoriaBuscada = repository.findById(id);

        if(categoriaBuscada.isPresent()){

            Categoria categoriaUpdate = categoriaBuscada.get();

            categoriaUpdate.setNombre(categoria.getNombre());
            categoriaUpdate.setDescripcion(categoria.getDescripcion());

            return repository.save(categoriaUpdate);
        }

        return null;
    }
}