package cl.duoc.usuarios_service.service;

import cl.duoc.usuarios_service.dto.UsuarioDTO;
import cl.duoc.usuarios_service.mapper.UsuarioMapper;
import cl.duoc.usuarios_service.model.Usuario;
import cl.duoc.usuarios_service.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository repository;

    @Autowired
    private UsuarioMapper mapper;

    public List<UsuarioDTO> findAll(){
        return repository.findAll()
                .stream()
                .map(mapper::toDTO)
                .toList();
    }

    public UsuarioDTO findById(Long id){
        return repository.findById(id)
                .map(mapper::toDTO)
                .orElse(null);
    }

    public UsuarioDTO save(Usuario usuario){
        return mapper.toDTO(repository.save(usuario));
    }

    public void delete(Long id){
        repository.deleteById(id);
    }

    public UsuarioDTO update(Long id, Usuario usuario){

        Optional<Usuario> usuarioBuscado = repository.findById(id);

        if(usuarioBuscado.isPresent()){

            Usuario usuarioUpdate = usuarioBuscado.get();

            usuarioUpdate.setNombre(usuario.getNombre());
            usuarioUpdate.setCorreo(usuario.getCorreo());
            usuarioUpdate.setPassword(usuario.getPassword());
            usuarioUpdate.setRol(usuario.getRol());

            return mapper.toDTO(repository.save(usuarioUpdate));
        }

        return null;
    }
}