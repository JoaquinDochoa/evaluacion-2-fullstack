package cl.duoc.usuarios_service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UsuarioDTO {

    private Long id;

    private String nombre;

    private String correo;

    private String rol;
}