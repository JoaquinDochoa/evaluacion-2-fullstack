package cl.duoc.inventario_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name = "inventario")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Inventario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private Long videojuegoId;

    @NotNull
    @PositiveOrZero
    private Integer stock;

    @NotNull
    private Long sucursalId;
}