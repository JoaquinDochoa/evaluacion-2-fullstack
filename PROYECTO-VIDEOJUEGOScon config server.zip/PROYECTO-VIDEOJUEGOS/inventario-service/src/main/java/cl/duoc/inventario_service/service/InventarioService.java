package cl.duoc.inventario_service.service;

import cl.duoc.inventario_service.clients.SucursalFeign;
import cl.duoc.inventario_service.clients.VideojuegoFeign;
import cl.duoc.inventario_service.dto.InventarioDTO;
import cl.duoc.inventario_service.model.Inventario;
import cl.duoc.inventario_service.repository.InventarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InventarioService {

    @Autowired
    private InventarioRepository repository;

    @Autowired
    private VideojuegoFeign videojuegoFeign;

    @Autowired
    private SucursalFeign sucursalFeign;

    public List<Inventario> findAll(){
        return repository.findAll();
    }

    public InventarioDTO findById(Long id){

        Inventario inventario = repository.findById(id).orElse(null);

        if(inventario == null){
            return null;
        }

        InventarioDTO dto = new InventarioDTO();

        dto.setId(inventario.getId());
        dto.setStock(inventario.getStock());

        dto.setVideojuego(
                videojuegoFeign.buscarVideojuego(inventario.getVideojuegoId())
        );

        dto.setSucursal(
                sucursalFeign.buscarSucursal(inventario.getSucursalId())
        );

        return dto;
    }

    public Inventario save(Inventario inventario){
        return repository.save(inventario);
    }

    public void delete(Long id){
        repository.deleteById(id);
    }

    public Inventario update(Long id, Inventario inventario){

        Optional<Inventario> inventarioBuscado = repository.findById(id);

        if(inventarioBuscado.isPresent()){

            Inventario inventarioUpdate = inventarioBuscado.get();

            inventarioUpdate.setVideojuegoId(inventario.getVideojuegoId());
            inventarioUpdate.setStock(inventario.getStock());
            inventarioUpdate.setSucursalId(inventario.getSucursalId());
            return repository.save(inventarioUpdate);
        }
        return null;
    }
}