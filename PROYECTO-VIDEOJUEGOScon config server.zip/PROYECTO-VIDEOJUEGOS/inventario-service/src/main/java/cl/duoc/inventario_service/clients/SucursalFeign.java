package cl.duoc.inventario_service.clients;

import cl.duoc.inventario_service.dto.SucursalDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "sucursales-service")
public interface SucursalFeign {

    @GetMapping("/api/v1/sucursales/{id}")
    SucursalDTO buscarSucursal(@PathVariable Long id);
}