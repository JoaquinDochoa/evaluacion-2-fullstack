package cl.duoc.inventario_service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventarioDTO {

    private Long id;

    private Integer stock;

    private VideojuegoDTO videojuego;

    private SucursalDTO sucursal;
}