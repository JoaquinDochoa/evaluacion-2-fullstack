package cl.duoc.inventario_service.mapper;

import cl.duoc.inventario_service.dto.InventarioDTO;
import cl.duoc.inventario_service.model.Inventario;
import org.springframework.stereotype.Component;

@Component
public class InventarioMapper {

    public InventarioDTO toDTO(Inventario inventario){

        if(inventario == null){
            return null;
        }

        InventarioDTO dto = new InventarioDTO();

        dto.setId(inventario.getId());
        dto.setStock(inventario.getStock());

        return dto;
    }
}