package cl.duoc.inventario_service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SucursalDTO {

    private Long id;

    private String nombre;

    private String direccion;

    private String telefono;
}