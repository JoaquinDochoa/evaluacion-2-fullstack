package cl.duoc.arriendos_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArriendosServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
