package cl.duoc.arriendos_service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VideojuegoDTO {

    private Long id;

    private String titulo;

    private String plataforma;

    private Double precioArriendo;
}