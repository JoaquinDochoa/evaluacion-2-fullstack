package cl.duoc.arriendos_service.dto;

import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArriendoDTO {

    private Long id;

    private LocalDate fecha;

    private UsuarioDTO usuario;

    private VideojuegoDTO videojuego;
}