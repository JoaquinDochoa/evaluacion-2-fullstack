package cl.duoc.arriendos_service.repository;

import cl.duoc.arriendos_service.model.Arriendo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ArriendoRepository extends JpaRepository<Arriendo, Long> {
}