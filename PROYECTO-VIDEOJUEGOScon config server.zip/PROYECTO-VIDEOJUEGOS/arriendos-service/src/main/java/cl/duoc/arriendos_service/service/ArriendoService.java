package cl.duoc.arriendos_service.service;

import cl.duoc.arriendos_service.clients.UsuarioFeign;
import cl.duoc.arriendos_service.clients.VideojuegoFeign;
import cl.duoc.arriendos_service.dto.ArriendoDTO;
import cl.duoc.arriendos_service.model.Arriendo;
import cl.duoc.arriendos_service.repository.ArriendoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArriendoService {

    @Autowired
    private ArriendoRepository repository;

    @Autowired
    private UsuarioFeign usuarioFeign;

    @Autowired
    private VideojuegoFeign videojuegoFeign;

    public List<Arriendo> findAll(){
        return repository.findAll();
    }

    public ArriendoDTO findById(Long id){

        Arriendo arriendo = repository.findById(id).orElse(null);

        if(arriendo == null){
            return null;
        }

        ArriendoDTO dto = new ArriendoDTO();

        dto.setId(arriendo.getId());
        dto.setFecha(arriendo.getFecha());

        dto.setUsuario(
                usuarioFeign.buscarUsuario(arriendo.getUsuarioId())
        );

        dto.setVideojuego(
                videojuegoFeign.buscarVideojuego(arriendo.getVideojuegoId())
        );

        return dto;
    }

    public Arriendo save(Arriendo arriendo){
        return repository.save(arriendo);
    }

    public void delete(Long id){
        repository.deleteById(id);
    }
}