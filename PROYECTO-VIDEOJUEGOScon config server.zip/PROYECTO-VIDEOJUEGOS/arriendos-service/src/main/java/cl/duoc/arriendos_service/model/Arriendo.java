package cl.duoc.arriendos_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "arriendos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Arriendo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private LocalDate fecha;

    @NotNull
    private Long usuarioId;

    @NotNull
    private Long videojuegoId;
}