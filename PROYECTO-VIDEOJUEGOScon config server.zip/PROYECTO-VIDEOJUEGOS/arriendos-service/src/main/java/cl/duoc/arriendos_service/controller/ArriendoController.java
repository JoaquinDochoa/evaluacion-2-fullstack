package cl.duoc.arriendos_service.controller;

import cl.duoc.arriendos_service.dto.ArriendoDTO;
import cl.duoc.arriendos_service.model.Arriendo;
import cl.duoc.arriendos_service.service.ArriendoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/arriendos")
public class ArriendoController {

    @Autowired
    private ArriendoService service;

    @GetMapping
    public ResponseEntity<List<Arriendo>> listar(){
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ArriendoDTO> buscar(@PathVariable Long id){

        ArriendoDTO dto = service.findById(id);

        if(dto == null){
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(dto);
    }

    @PostMapping
    public ResponseEntity<Arriendo> guardar(@Valid @RequestBody Arriendo arriendo){
        return ResponseEntity.ok(service.save(arriendo));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id){

        service.delete(id);

        return ResponseEntity.noContent().build();
    }
}