package cl.duoc.arriendos_service.clients;

import cl.duoc.arriendos_service.dto.UsuarioDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "usuarios-service")
public interface UsuarioFeign {

    @GetMapping("/api/v1/usuarios/{id}")
    UsuarioDTO buscarUsuario(@PathVariable Long id);
}