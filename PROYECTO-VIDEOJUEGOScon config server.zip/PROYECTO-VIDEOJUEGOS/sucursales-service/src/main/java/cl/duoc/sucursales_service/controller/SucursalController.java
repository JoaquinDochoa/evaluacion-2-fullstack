package cl.duoc.sucursales_service.controller;

import cl.duoc.sucursales_service.model.Sucursal;
import cl.duoc.sucursales_service.service.SucursalService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/sucursales")
public class SucursalController {

    @Autowired
    private SucursalService service;

    @GetMapping
    public ResponseEntity<List<Sucursal>> listar(){
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Sucursal> buscar(@PathVariable Long id){

        Sucursal sucursal = service.findById(id);

        if(sucursal == null){
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(sucursal);
    }

    @PostMapping
    public ResponseEntity<Sucursal> guardar(@Valid @RequestBody Sucursal sucursal){
        return ResponseEntity.ok(service.save(sucursal));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Sucursal> actualizar(@PathVariable Long id,
                                               @Valid @RequestBody Sucursal sucursal){

        Sucursal sucursalActualizada = service.update(id, sucursal);

        if(sucursalActualizada == null){
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(sucursalActualizada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id){

        service.delete(id);

        return ResponseEntity.noContent().build();
    }
}