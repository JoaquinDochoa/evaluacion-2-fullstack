package cl.duoc.sucursales_service.service;

import cl.duoc.sucursales_service.model.Sucursal;
import cl.duoc.sucursales_service.repository.SucursalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SucursalService {

    @Autowired
    private SucursalRepository repository;

    public List<Sucursal> findAll(){
        return repository.findAll();
    }

    public Sucursal findById(Long id){
        return repository.findById(id).orElse(null);
    }

    public Sucursal save(Sucursal sucursal){
        return repository.save(sucursal);
    }

    public void delete(Long id){
        repository.deleteById(id);
    }

    public Sucursal update(Long id, Sucursal sucursal){

        Optional<Sucursal> sucursalBuscada = repository.findById(id);

        if(sucursalBuscada.isPresent()){

            Sucursal sucursalUpdate = sucursalBuscada.get();

            sucursalUpdate.setNombre(sucursal.getNombre());
            sucursalUpdate.setDireccion(sucursal.getDireccion());
            sucursalUpdate.setTelefono(sucursal.getTelefono());

            return repository.save(sucursalUpdate);
        }

        return null;
    }
}