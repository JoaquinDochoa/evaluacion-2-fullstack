package cl.duoc.reservas_service.controller;

import cl.duoc.reservas_service.dto.ReservaDTO;
import cl.duoc.reservas_service.model.Reserva;
import cl.duoc.reservas_service.service.ReservaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/reservas")
public class ReservaController {

    @Autowired
    private ReservaService service;

    @GetMapping
    public ResponseEntity<List<Reserva>> listar(){
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReservaDTO> buscar(@PathVariable Long id){

        ReservaDTO dto = service.findById(id);

        if(dto == null){
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(dto);
    }

    @PostMapping
    public ResponseEntity<Reserva> guardar(@Valid @RequestBody Reserva reserva){
        return ResponseEntity.ok(service.save(reserva));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Reserva> actualizar(@PathVariable Long id,
                                              @Valid @RequestBody Reserva reserva){

        Reserva reservaActualizada = service.update(id, reserva);

        if(reservaActualizada == null){
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(reservaActualizada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id){

        service.delete(id);

        return ResponseEntity.noContent().build();
    }
}