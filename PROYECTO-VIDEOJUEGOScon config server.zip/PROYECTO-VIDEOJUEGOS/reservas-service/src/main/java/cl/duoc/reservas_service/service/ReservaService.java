package cl.duoc.reservas_service.service;

import cl.duoc.reservas_service.clients.UsuarioFeign;
import cl.duoc.reservas_service.clients.VideojuegoFeign;
import cl.duoc.reservas_service.dto.ReservaDTO;
import cl.duoc.reservas_service.model.Reserva;
import cl.duoc.reservas_service.repository.ReservaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository repository;

    @Autowired
    private UsuarioFeign usuarioFeign;

    @Autowired
    private VideojuegoFeign videojuegoFeign;

    public List<Reserva> findAll(){
        return repository.findAll();
    }

    public ReservaDTO findById(Long id){

        Reserva reserva = repository.findById(id).orElse(null);

        if(reserva == null){
            return null;
        }

        ReservaDTO dto = new ReservaDTO();

        dto.setId(reserva.getId());
        dto.setFechaReserva(reserva.getFechaReserva());
        dto.setEstado(reserva.getEstado());

        dto.setUsuario(
                usuarioFeign.buscarUsuario(reserva.getUsuarioId())
        );

        dto.setVideojuego(
                videojuegoFeign.buscarVideojuego(reserva.getVideojuegoId())
        );

        return dto;
    }

    public Reserva save(Reserva reserva){
        return repository.save(reserva);
    }

    public void delete(Long id){
        repository.deleteById(id);
    }

    public Reserva update(Long id, Reserva reserva){

        Optional<Reserva> reservaBuscada = repository.findById(id);

        if(reservaBuscada.isPresent()){

            Reserva reservaUpdate = reservaBuscada.get();

            reservaUpdate.setFechaReserva(reserva.getFechaReserva());
            reservaUpdate.setEstado(reserva.getEstado());
            reservaUpdate.setUsuarioId(reserva.getUsuarioId());
            reservaUpdate.setVideojuegoId(reserva.getVideojuegoId());

            return repository.save(reservaUpdate);
        }

        return null;
    }
}