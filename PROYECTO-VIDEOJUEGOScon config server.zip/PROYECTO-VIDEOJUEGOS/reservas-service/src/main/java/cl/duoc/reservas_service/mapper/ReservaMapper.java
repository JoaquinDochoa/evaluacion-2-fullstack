package cl.duoc.reservas_service.mapper;

import cl.duoc.reservas_service.dto.ReservaDTO;
import cl.duoc.reservas_service.model.Reserva;
import org.springframework.stereotype.Component;

@Component
public class ReservaMapper {

    public ReservaDTO toDTO(Reserva reserva){

        if(reserva == null){
            return null;
        }

        ReservaDTO dto = new ReservaDTO();

        dto.setId(reserva.getId());
        dto.setFechaReserva(reserva.getFechaReserva());
        dto.setEstado(reserva.getEstado());

        return dto;
    }
}