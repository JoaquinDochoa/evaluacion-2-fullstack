package cl.duoc.reservas_service.dto;

import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReservaDTO {

    private Long id;

    private LocalDate fechaReserva;

    private String estado;

    private UsuarioDTO usuario;

    private VideojuegoDTO videojuego;
}