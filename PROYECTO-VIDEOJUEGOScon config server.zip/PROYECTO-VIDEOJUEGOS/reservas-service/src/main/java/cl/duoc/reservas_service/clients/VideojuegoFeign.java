package cl.duoc.reservas_service.clients;

import cl.duoc.reservas_service.dto.VideojuegoDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "videojuegos-service")
public interface VideojuegoFeign {

    @GetMapping("/api/v1/videojuegos/{id}")
    VideojuegoDTO buscarVideojuego(@PathVariable Long id);
}