package cl.duoc.pagos_service.dto;

import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ArriendoDTO {

    private Long id;

    private LocalDate fecha;

    private Long usuarioId;

    private Long videojuegoId;
}