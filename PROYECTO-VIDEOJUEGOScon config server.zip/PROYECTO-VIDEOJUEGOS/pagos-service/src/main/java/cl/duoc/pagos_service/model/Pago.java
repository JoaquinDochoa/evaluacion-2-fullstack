package cl.duoc.pagos_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name = "pagos")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Positive
    private Double monto;

    @NotBlank
    private String metodoPago;

    @NotBlank
    private String estado;

    @NotNull
    private Long arriendoId;
}