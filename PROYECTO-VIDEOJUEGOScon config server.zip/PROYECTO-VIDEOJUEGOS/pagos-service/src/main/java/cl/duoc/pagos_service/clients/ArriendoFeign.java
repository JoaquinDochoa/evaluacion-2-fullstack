package cl.duoc.pagos_service.clients;

import cl.duoc.pagos_service.dto.ArriendoDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "arriendos-service")
public interface ArriendoFeign {

    @GetMapping("/api/v1/arriendos/{id}")
    ArriendoDTO buscarArriendo(@PathVariable Long id);
}