package cl.duoc.pagos_service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PagoDTO {

    private Long id;

    private Double monto;

    private String metodoPago;

    private String estado;

    private ArriendoDTO arriendo;
}