package cl.duoc.pagos_service.service;

import cl.duoc.pagos_service.clients.ArriendoFeign;
import cl.duoc.pagos_service.dto.PagoDTO;
import cl.duoc.pagos_service.model.Pago;
import cl.duoc.pagos_service.repository.PagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PagoService {

    @Autowired
    private PagoRepository repository;

    @Autowired
    private ArriendoFeign arriendoFeign;

    public List<Pago> findAll(){
        return repository.findAll();
    }

    public PagoDTO findById(Long id){

        Pago pago = repository.findById(id).orElse(null);

        if(pago == null){
            return null;
        }

        PagoDTO dto = new PagoDTO();

        dto.setId(pago.getId());
        dto.setMonto(pago.getMonto());
        dto.setMetodoPago(pago.getMetodoPago());
        dto.setEstado(pago.getEstado());

        dto.setArriendo(
                arriendoFeign.buscarArriendo(pago.getArriendoId())
        );

        return dto;
    }

    public Pago save(Pago pago){
        return repository.save(pago);
    }

    public void delete(Long id){
        repository.deleteById(id);
    }

    public Pago update(Long id, Pago pago){

        Optional<Pago> pagoBuscado = repository.findById(id);

        if(pagoBuscado.isPresent()){

            Pago pagoUpdate = pagoBuscado.get();

            pagoUpdate.setMonto(pago.getMonto());
            pagoUpdate.setMetodoPago(pago.getMetodoPago());
            pagoUpdate.setEstado(pago.getEstado());
            pagoUpdate.setArriendoId(pago.getArriendoId());

            return repository.save(pagoUpdate);
        }

        return null;
    }
}