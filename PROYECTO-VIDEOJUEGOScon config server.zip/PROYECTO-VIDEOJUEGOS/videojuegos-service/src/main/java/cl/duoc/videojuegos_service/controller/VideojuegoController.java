package cl.duoc.videojuegos_service.controller;

import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.service.VideojuegoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/api/v1/videojuegos")
public class VideojuegoController {

    @Autowired
    private VideojuegoService service;

    @GetMapping
    public ResponseEntity<List<Videojuego>> listar(){
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<VideojuegoDTO> buscar(@PathVariable Long id){

        VideojuegoDTO dto = service.findById(id);

        if(dto == null){
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(dto);
    }

    @PostMapping
    public ResponseEntity<Videojuego> guardar(@Valid @RequestBody Videojuego videojuego){
        return ResponseEntity.ok(service.save(videojuego));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Videojuego> actualizar(@PathVariable Long id,
                                                 @Valid @RequestBody Videojuego videojuego){

        Videojuego videojuegoActualizado = service.update(id, videojuego);

        if(videojuegoActualizado == null){
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(videojuegoActualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id){

        service.delete(id);

        return ResponseEntity.noContent().build();
    }
}