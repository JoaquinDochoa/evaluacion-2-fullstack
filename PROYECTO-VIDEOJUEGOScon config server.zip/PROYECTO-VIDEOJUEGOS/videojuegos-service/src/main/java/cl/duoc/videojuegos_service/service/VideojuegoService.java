package cl.duoc.videojuegos_service.service;

import cl.duoc.videojuegos_service.clients.CategoriaFeign;
import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.repository.VideojuegoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VideojuegoService {

    @Autowired
    private VideojuegoRepository repository;

    @Autowired
    private CategoriaFeign categoriaFeign;

    public List<Videojuego> findAll(){
        return repository.findAll();
    }

    public VideojuegoDTO findById(Long id){

        Videojuego videojuego = repository.findById(id).orElse(null);

        if(videojuego == null){
            return null;
        }

        VideojuegoDTO dto = new VideojuegoDTO();

        dto.setId(videojuego.getId());
        dto.setTitulo(videojuego.getTitulo());
        dto.setPlataforma(videojuego.getPlataforma());
        dto.setPrecioArriendo(videojuego.getPrecioArriendo());
        dto.setStock(videojuego.getStock());

        dto.setCategoria(
                categoriaFeign.buscarCategoria(videojuego.getCategoriaId())
        );

        return dto;
    }

    public Videojuego save(Videojuego videojuego){
        return repository.save(videojuego);
    }

    public void delete(Long id){
        repository.deleteById(id);
    }

    public Videojuego update(Long id, Videojuego videojuego){

        Optional<Videojuego> videojuegoBuscado = repository.findById(id);

        if(videojuegoBuscado.isPresent()){

            Videojuego videojuegoUpdate = videojuegoBuscado.get();

            videojuegoUpdate.setTitulo(videojuego.getTitulo());
            videojuegoUpdate.setPlataforma(videojuego.getPlataforma());
            videojuegoUpdate.setPrecioArriendo(videojuego.getPrecioArriendo());
            videojuegoUpdate.setStock(videojuego.getStock());
            videojuegoUpdate.setCategoriaId(videojuego.getCategoriaId());

            return repository.save(videojuegoUpdate);
        }

        return null;
    }
}