package cl.duoc.videojuegos_service.clients;

import cl.duoc.videojuegos_service.dto.CategoriaDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "categorias-service")
public interface CategoriaFeign {

    @GetMapping("/api/v1/categorias/{id}")
    CategoriaDTO buscarCategoria(@PathVariable Long id);
}