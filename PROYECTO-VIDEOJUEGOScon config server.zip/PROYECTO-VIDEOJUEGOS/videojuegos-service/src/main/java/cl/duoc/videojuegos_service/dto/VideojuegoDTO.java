package cl.duoc.videojuegos_service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VideojuegoDTO {

    private Long id;

    private String titulo;

    private String plataforma;

    private Double precioArriendo;

    private Integer stock;

    private CategoriaDTO categoria;
}