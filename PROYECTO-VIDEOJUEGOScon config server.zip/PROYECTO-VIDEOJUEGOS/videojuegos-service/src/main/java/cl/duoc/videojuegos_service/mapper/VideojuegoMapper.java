package cl.duoc.videojuegos_service.mapper;

import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.model.Videojuego;
import org.springframework.stereotype.Component;

@Component
public class VideojuegoMapper {

    public VideojuegoDTO toDTO(Videojuego videojuego){

        if(videojuego == null){
            return null;
        }

        VideojuegoDTO dto = new VideojuegoDTO();

        dto.setId(videojuego.getId());
        dto.setTitulo(videojuego.getTitulo());
        dto.setPlataforma(videojuego.getPlataforma());
        dto.setPrecioArriendo(videojuego.getPrecioArriendo());
        dto.setStock(videojuego.getStock());

        return dto;
    }
}