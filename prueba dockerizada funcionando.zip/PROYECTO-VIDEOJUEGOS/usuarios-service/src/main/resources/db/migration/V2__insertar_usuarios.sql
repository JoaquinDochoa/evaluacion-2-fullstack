INSERT INTO usuarios (nombre, correo, password, rol) VALUES
    ('Carlos Mendoza',    'carlos.mendoza@gmail.com',  'pass1234', 'ADMIN'),
    ('María López',      'maria.lopez@gmail.com',      'pass1234', 'CLIENTE'),
    ('Jorge Ramírez',    'jorge.ramirez@gmail.com',    'pass1234', 'CLIENTE'),
    ('Valentina Torres', 'valentina.torres@gmail.com', 'pass1234', 'CLIENTE'),
    ('Andrés Fuentes',   'andres.fuentes@gmail.com',   'pass1234', 'EMPLEADO');