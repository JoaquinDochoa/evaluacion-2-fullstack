package cl.duoc.usuarios_service.controller;

import cl.duoc.usuarios_service.dto.UsuarioDTO;
import cl.duoc.usuarios_service.model.Usuario;
import cl.duoc.usuarios_service.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    @GetMapping
    public ResponseEntity<List<UsuarioDTO>> listar() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UsuarioDTO> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    public ResponseEntity<UsuarioDTO> guardar(@Valid @RequestBody Usuario usuario) {
        return ResponseEntity.ok(service.save(usuario));
    }

    @PutMapping("/{id}")
    public ResponseEntity<UsuarioDTO> actualizar(@PathVariable Long id,
                                                 @Valid @RequestBody Usuario usuario) {
        return ResponseEntity.ok(service.update(id, usuario));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // ── REPORTES ──────────────────────────────────────────

    // GET /api/v1/usuarios/buscar/correo?correo=juan@gmail.com
    @GetMapping("/buscar/correo")
    public ResponseEntity<UsuarioDTO> buscarPorCorreo(@RequestParam String correo) {
        return ResponseEntity.ok(service.findByCorreo(correo));
    }

    // GET /api/v1/usuarios/buscar/rol?rol=ADMIN
    @GetMapping("/buscar/rol")
    public ResponseEntity<List<UsuarioDTO>> buscarPorRol(@RequestParam String rol) {
        return ResponseEntity.ok(service.findByRol(rol));
    }

    // GET /api/v1/usuarios/buscar/nombre?nombre=carlos
    @GetMapping("/buscar/nombre")
    public ResponseEntity<List<UsuarioDTO>> buscarPorNombre(@RequestParam String nombre) {
        return ResponseEntity.ok(service.findByNombre(nombre));
    }
}