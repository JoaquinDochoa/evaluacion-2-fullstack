package cl.duoc.usuarios_service.service;

import cl.duoc.usuarios_service.dto.UsuarioDTO;
import cl.duoc.usuarios_service.exception.UsuarioNotFoundException;
import cl.duoc.usuarios_service.mapper.UsuarioMapper;
import cl.duoc.usuarios_service.model.Usuario;
import cl.duoc.usuarios_service.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository repository;

    @Autowired
    private UsuarioMapper mapper;

    public List<UsuarioDTO> findAll() {
        return repository.findAll().stream().map(mapper::toDTO).toList();
    }

    public UsuarioDTO findById(Long id) {
        return repository.findById(id)
                .map(mapper::toDTO)
                .orElseThrow(() -> new UsuarioNotFoundException(id));
    }

    public UsuarioDTO save(Usuario usuario) {
        return mapper.toDTO(repository.save(usuario));
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) throw new UsuarioNotFoundException(id);
        repository.deleteById(id);
    }

    public UsuarioDTO update(Long id, Usuario usuario) {
        Usuario u = repository.findById(id)
                .orElseThrow(() -> new UsuarioNotFoundException(id));
        u.setNombre(usuario.getNombre());
        u.setCorreo(usuario.getCorreo());
        u.setPassword(usuario.getPassword());
        u.setRol(usuario.getRol());
        return mapper.toDTO(repository.save(u));
    }

    // ── REPORTES ──────────────────────────────────────────
    public UsuarioDTO findByCorreo(String correo) {
        return repository.findByCorreo(correo)
                .map(mapper::toDTO)
                .orElseThrow(() -> new UsuarioNotFoundException(correo));
    }

    public List<UsuarioDTO> findByRol(String rol) {
        return repository.findByRol(rol).stream().map(mapper::toDTO).toList();
    }

    public List<UsuarioDTO> findByNombre(String nombre) {
        return repository.findByNombreContainingIgnoreCase(nombre)
                .stream().map(mapper::toDTO).toList();
    }
}