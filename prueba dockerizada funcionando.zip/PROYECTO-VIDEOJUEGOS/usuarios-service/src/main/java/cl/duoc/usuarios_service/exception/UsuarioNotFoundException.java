package cl.duoc.usuarios_service.exception;

public class UsuarioNotFoundException extends RuntimeException {

    public UsuarioNotFoundException(Long id) {
        super("Usuario con id " + id + " no encontrado");
    }

    public UsuarioNotFoundException(String correo) {
        super("Usuario con correo " + correo + " no encontrado");
    }
}