INSERT INTO videojuegos (titulo, plataforma, precio_arriendo, stock, categoria_id) VALUES
('God of War Ragnarok', 'PS5',          3990.0, 8,  1),
('Elden Ring',          'PC',           2990.0, 5,  2),
('FIFA 25',             'PS5',          2500.0, 10, 3),
('Resident Evil 4',     'PS5',          2990.0, 6,  4),
('Civilization VII',    'PC',           1990.0, 4,  5),
('Spider-Man 2',        'PS5',          3500.0, 7,  1),
('Halo Infinite',       'XBOX SERIES X',2990.0, 5,  1);