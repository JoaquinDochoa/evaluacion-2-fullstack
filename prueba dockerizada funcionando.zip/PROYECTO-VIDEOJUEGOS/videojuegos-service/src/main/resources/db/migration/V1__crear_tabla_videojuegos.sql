CREATE TABLE IF NOT EXISTS videojuegos (
    id               BIGINT       AUTO_INCREMENT PRIMARY KEY,
    titulo           VARCHAR(150) NOT NULL,
    plataforma       VARCHAR(50)  NOT NULL,
    precio_arriendo  DOUBLE       NOT NULL,
    stock            INT          NOT NULL,
    categoria_id     BIGINT       NOT NULL
    );