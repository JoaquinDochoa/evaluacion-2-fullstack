package cl.duoc.videojuegos_service.controller;

import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.service.VideojuegoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/videojuegos")
public class VideojuegoController {

    @Autowired
    private VideojuegoService service;

    @GetMapping
    public ResponseEntity<List<VideojuegoDTO>> listar() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<VideojuegoDTO> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    public ResponseEntity<VideojuegoDTO> guardar(@Valid @RequestBody Videojuego videojuego) {
        return ResponseEntity.ok(service.save(videojuego));
    }

    @PutMapping("/{id}")
    public ResponseEntity<VideojuegoDTO> actualizar(@PathVariable Long id,
                                                    @Valid @RequestBody Videojuego videojuego) {
        return ResponseEntity.ok(service.update(id, videojuego));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // ── REPORTES ──────────────────────────────────────────

    // GET /api/v1/videojuegos/buscar/plataforma?plataforma=PS5
    @GetMapping("/buscar/plataforma")
    public ResponseEntity<List<VideojuegoDTO>> buscarPorPlataforma(@RequestParam String plataforma) {
        return ResponseEntity.ok(service.findByPlataforma(plataforma));
    }

    // GET /api/v1/videojuegos/buscar/categoria?categoriaId=1
    @GetMapping("/buscar/categoria")
    public ResponseEntity<List<VideojuegoDTO>> buscarPorCategoria(@RequestParam Long categoriaId) {
        return ResponseEntity.ok(service.findByCategoria(categoriaId));
    }

    // GET /api/v1/videojuegos/buscar/precio?max=3000
    @GetMapping("/buscar/precio")
    public ResponseEntity<List<VideojuegoDTO>> buscarPorPrecio(@RequestParam Double max) {
        return ResponseEntity.ok(service.findByPrecioMaximo(max));
    }

    // GET /api/v1/videojuegos/buscar/titulo?titulo=god
    @GetMapping("/buscar/titulo")
    public ResponseEntity<List<VideojuegoDTO>> buscarPorTitulo(@RequestParam String titulo) {
        return ResponseEntity.ok(service.findByTitulo(titulo));
    }

    // GET /api/v1/videojuegos/disponibles
    @GetMapping("/disponibles")
    public ResponseEntity<List<VideojuegoDTO>> disponibles() {
        return ResponseEntity.ok(service.findDisponibles());
    }
}