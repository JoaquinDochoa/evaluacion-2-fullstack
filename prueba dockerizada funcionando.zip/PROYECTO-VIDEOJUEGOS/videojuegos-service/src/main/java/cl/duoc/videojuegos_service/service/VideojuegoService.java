package cl.duoc.videojuegos_service.service;

import cl.duoc.videojuegos_service.clients.CategoriaFeign;
import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.exception.VideojuegoNotFoundException;
import cl.duoc.videojuegos_service.mapper.VideojuegoMapper;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.repository.VideojuegoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VideojuegoService {

    @Autowired
    private VideojuegoRepository repository;

    @Autowired
    private CategoriaFeign categoriaFeign;

    @Autowired
    private VideojuegoMapper mapper;

    private final List<String> PLATAFORMAS_PERMITIDAS = List.of(
            "PS4", "PS5", "XBOX ONE", "XBOX SERIES X", "NINTENDO SWITCH", "PC"
    );

    public List<VideojuegoDTO> findAll() {
        return repository.findAll().stream().map(mapper::toDTO).toList();
    }

    public VideojuegoDTO findById(Long id) {
        Videojuego v = repository.findById(id)
                .orElseThrow(() -> new VideojuegoNotFoundException(id));
        VideojuegoDTO dto = mapper.toDTO(v);
        dto.setCategoria(categoriaFeign.buscarCategoria(v.getCategoriaId()));
        return dto;
    }

    public VideojuegoDTO save(Videojuego videojuego) {

        if (!PLATAFORMAS_PERMITIDAS.contains(videojuego.getPlataforma().toUpperCase())) {
            throw new IllegalArgumentException(
                    "No se pudo guardar el videojuego. La plataforma '" +
                            videojuego.getPlataforma() +
                            "' no es válida. Las plataformas permitidas son: " +
                            String.join(", ", PLATAFORMAS_PERMITIDAS)
            );
        }

        return mapper.toDTO(repository.save(videojuego));
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) throw new VideojuegoNotFoundException(id);
        repository.deleteById(id);
    }

    public VideojuegoDTO update(Long id, Videojuego videojuego) {

        if (!PLATAFORMAS_PERMITIDAS.contains(videojuego.getPlataforma().toUpperCase())) {
            throw new IllegalArgumentException(
                    "No se pudo actualizar el videojuego. La plataforma '" +
                            videojuego.getPlataforma() +
                            "' no es válida. Las plataformas permitidas son: " +
                            String.join(", ", PLATAFORMAS_PERMITIDAS)
            );
        }

        Videojuego v = repository.findById(id)
                .orElseThrow(() -> new VideojuegoNotFoundException(id));
        v.setTitulo(videojuego.getTitulo());
        v.setPlataforma(videojuego.getPlataforma().toUpperCase());
        v.setPrecioArriendo(videojuego.getPrecioArriendo());
        v.setStock(videojuego.getStock());
        v.setCategoriaId(videojuego.getCategoriaId());
        return mapper.toDTO(repository.save(v));
    }

    // ── REPORTES ──────────────────────────────────────────
    public List<VideojuegoDTO> findByPlataforma(String plataforma) {
        return repository.findByPlataforma(plataforma).stream().map(mapper::toDTO).toList();
    }

    public List<VideojuegoDTO> findByCategoria(Long categoriaId) {
        return repository.findByCategoriaId(categoriaId).stream().map(mapper::toDTO).toList();
    }

    public List<VideojuegoDTO> findByPrecioMaximo(Double precio) {
        return repository.findByPrecioArriendoLessThanEqual(precio).stream().map(mapper::toDTO).toList();
    }

    public List<VideojuegoDTO> findByTitulo(String titulo) {
        return repository.findByTituloContainingIgnoreCase(titulo).stream().map(mapper::toDTO).toList();
    }

    public List<VideojuegoDTO> findDisponibles() {
        return repository.findByStockGreaterThan(0).stream().map(mapper::toDTO).toList();
    }
}