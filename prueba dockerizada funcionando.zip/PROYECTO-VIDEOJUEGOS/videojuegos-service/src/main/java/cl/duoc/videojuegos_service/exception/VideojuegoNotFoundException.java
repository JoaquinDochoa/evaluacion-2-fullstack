package cl.duoc.videojuegos_service.exception;

public class VideojuegoNotFoundException extends RuntimeException {

    public VideojuegoNotFoundException(Long id) {
        super("Videojuego con id " + id + " no encontrado");
    }

    public VideojuegoNotFoundException(String titulo) {
        super("Videojuego con titulo '" + titulo + "' no encontrado");
    }
}