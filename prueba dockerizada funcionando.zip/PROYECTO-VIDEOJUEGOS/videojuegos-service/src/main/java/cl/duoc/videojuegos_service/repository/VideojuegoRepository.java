package cl.duoc.videojuegos_service.repository;

import cl.duoc.videojuegos_service.model.Videojuego;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VideojuegoRepository extends JpaRepository<Videojuego, Long> {

    List<Videojuego> findByPlataforma(String plataforma);

    List<Videojuego> findByCategoriaId(Long categoriaId);

    List<Videojuego> findByPrecioArriendoLessThanEqual(Double precio);

    List<Videojuego> findByTituloContainingIgnoreCase(String titulo);

    List<Videojuego> findByStockGreaterThan(Integer stock);
}