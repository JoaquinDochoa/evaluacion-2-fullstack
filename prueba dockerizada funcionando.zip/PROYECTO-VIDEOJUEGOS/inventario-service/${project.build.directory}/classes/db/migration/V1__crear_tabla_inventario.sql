CREATE TABLE IF NOT EXISTS inventario (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    videojuego_id  BIGINT  NOT NULL,
    stock          INT     NOT NULL,
    sucursal_id    BIGINT  NOT NULL
);