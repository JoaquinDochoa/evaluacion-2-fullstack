INSERT INTO inventario (videojuego_id, stock, sucursal_id) VALUES
(1, 3, 1),
(2, 2, 1),
(3, 5, 2),
(4, 2, 3),
(5, 1, 4),
(6, 4, 2),
(7, 2, 5);