CREATE TABLE IF NOT EXISTS sucursales (
    id        BIGINT      AUTO_INCREMENT PRIMARY KEY,
    nombre    VARCHAR(100) NOT NULL,
    direccion VARCHAR(255) NOT NULL,
    telefono  VARCHAR(12)  NOT NULL
);