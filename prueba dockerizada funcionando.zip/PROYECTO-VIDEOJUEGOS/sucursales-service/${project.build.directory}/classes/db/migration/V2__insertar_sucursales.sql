INSERT INTO sucursales (nombre, direccion, telefono) VALUES
('Sucursal Centro',      'Av. Libertador 1234, Santiago',     '222345678'),
('Sucursal Providencia', 'Av. Providencia 567, Santiago',     '222456789'),
('Sucursal Maipú',       'Av. Pajaritos 890, Maipú',          '222567890'),
('Sucursal La Florida',  'Av. Vicuña Mackenna 1100, Florida', '222678901'),
('Sucursal Viña',        'Av. Libertad 432, Viña del Mar',    '322789012');