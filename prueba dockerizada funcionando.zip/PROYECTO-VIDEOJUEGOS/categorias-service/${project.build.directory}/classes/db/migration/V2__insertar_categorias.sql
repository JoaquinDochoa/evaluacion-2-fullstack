INSERT INTO categorias (nombre, descripcion) VALUES
    ('Acción',     'Juegos de combate y aventura en tiempo real'),
    ('RPG',        'Juegos de rol con historia profunda y desarrollo de personajes'),
    ('Deportes',   'Simulaciones deportivas de fútbol, básquetbol y más'),
    ('Terror',     'Juegos de suspenso y horror con ambientación oscura'),
    ('Estrategia', 'Juegos de planificación y toma de decisiones');