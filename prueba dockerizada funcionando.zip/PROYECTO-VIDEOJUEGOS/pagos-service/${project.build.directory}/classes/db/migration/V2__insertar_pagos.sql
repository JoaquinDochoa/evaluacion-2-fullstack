INSERT INTO pagos (monto, metodo_pago, estado, arriendo_id) VALUES
(3990.0, 'TARJETA',      'PAGADO',    1),
(2500.0, 'EFECTIVO',     'PAGADO',    2),
(2990.0, 'TRANSFERENCIA','PAGADO',    3),
(2990.0, 'TARJETA',      'PENDIENTE', 4),
(3500.0, 'EFECTIVO',     'PAGADO',    5);