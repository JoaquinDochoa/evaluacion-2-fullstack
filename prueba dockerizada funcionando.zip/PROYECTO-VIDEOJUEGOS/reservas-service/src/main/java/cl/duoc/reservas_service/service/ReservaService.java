package cl.duoc.reservas_service.service;

import cl.duoc.reservas_service.clients.UsuarioFeign;
import cl.duoc.reservas_service.clients.VideojuegoFeign;
import cl.duoc.reservas_service.dto.ReservaDTO;
import cl.duoc.reservas_service.exception.ReservaNotFoundException;
import cl.duoc.reservas_service.model.Reserva;
import cl.duoc.reservas_service.repository.ReservaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository repository;

    @Autowired
    private UsuarioFeign usuarioFeign;

    @Autowired
    private VideojuegoFeign videojuegoFeign;

    public List<ReservaDTO> findAll() {
        return repository.findAll().stream().map(this::toDTO).toList();
    }

    public ReservaDTO findById(Long id) {
        Reserva r = repository.findById(id)
                .orElseThrow(() -> new ReservaNotFoundException(id));
        return toDTO(r);
    }

    public ReservaDTO save(Reserva reserva) {
        return toDTO(repository.save(reserva));
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) throw new ReservaNotFoundException(id);
        repository.deleteById(id);
    }

    public ReservaDTO update(Long id, Reserva reserva) {
        Reserva r = repository.findById(id)
                .orElseThrow(() -> new ReservaNotFoundException(id));
        r.setFechaReserva(reserva.getFechaReserva());
        r.setEstado(reserva.getEstado());
        r.setUsuarioId(reserva.getUsuarioId());
        r.setVideojuegoId(reserva.getVideojuegoId());
        return toDTO(repository.save(r));
    }

    // ── REPORTES ──────────────────────────────────────────
    public List<ReservaDTO> findByEstado(String estado) {
        return repository.findByEstado(estado).stream().map(this::toDTO).toList();
    }

    public List<ReservaDTO> findByUsuario(Long usuarioId) {
        return repository.findByUsuarioId(usuarioId).stream().map(this::toDTO).toList();
    }

    public List<ReservaDTO> findByVideojuego(Long videojuegoId) {
        return repository.findByVideojuegoId(videojuegoId).stream().map(this::toDTO).toList();
    }

    public List<ReservaDTO> findByFechas(LocalDate desde, LocalDate hasta) {
        return repository.findByFechaReservaBetween(desde, hasta)
                .stream().map(this::toDTO).toList();
    }

    // ── Conversión a DTO con Feign ─────────────────────────
    private ReservaDTO toDTO(Reserva r) {
        ReservaDTO dto = new ReservaDTO();
        dto.setId(r.getId());
        dto.setFechaReserva(r.getFechaReserva());
        dto.setEstado(r.getEstado());
        dto.setUsuario(usuarioFeign.buscarUsuario(r.getUsuarioId()));
        dto.setVideojuego(videojuegoFeign.buscarVideojuego(r.getVideojuegoId()));
        return dto;
    }
}