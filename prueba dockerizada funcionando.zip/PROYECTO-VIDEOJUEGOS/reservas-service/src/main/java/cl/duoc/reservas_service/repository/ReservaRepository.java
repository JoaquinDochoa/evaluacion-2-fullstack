package cl.duoc.reservas_service.repository;

import cl.duoc.reservas_service.model.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ReservaRepository extends JpaRepository<Reserva, Long> {

    List<Reserva> findByEstado(String estado);

    List<Reserva> findByUsuarioId(Long usuarioId);

    List<Reserva> findByVideojuegoId(Long videojuegoId);

    List<Reserva> findByFechaReservaBetween(LocalDate desde, LocalDate hasta);
}