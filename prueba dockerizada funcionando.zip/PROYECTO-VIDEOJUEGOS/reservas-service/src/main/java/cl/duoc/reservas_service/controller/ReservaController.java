package cl.duoc.reservas_service.controller;

import cl.duoc.reservas_service.dto.ReservaDTO;
import cl.duoc.reservas_service.model.Reserva;
import cl.duoc.reservas_service.service.ReservaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1/reservas")
public class ReservaController {

    @Autowired
    private ReservaService service;

    @GetMapping
    public ResponseEntity<List<ReservaDTO>> listar() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReservaDTO> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    public ResponseEntity<ReservaDTO> guardar(@Valid @RequestBody Reserva reserva) {
        return ResponseEntity.ok(service.save(reserva));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ReservaDTO> actualizar(@PathVariable Long id,
                                                 @Valid @RequestBody Reserva reserva) {
        return ResponseEntity.ok(service.update(id, reserva));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // ── nuevos getmapping

    // GET /api/v1/reservas/buscar/estado?estado=PENDIENTE
    @GetMapping("/buscar/estado")
    public ResponseEntity<List<ReservaDTO>> buscarPorEstado(@RequestParam String estado) {
        return ResponseEntity.ok(service.findByEstado(estado));
    }

    // GET /api/v1/reservas/buscar/usuario?usuarioId=1
    @GetMapping("/buscar/usuario")
    public ResponseEntity<List<ReservaDTO>> buscarPorUsuario(@RequestParam Long usuarioId) {
        return ResponseEntity.ok(service.findByUsuario(usuarioId));
    }

    // GET /api/v1/reservas/buscar/videojuego?videojuegoId=1
    @GetMapping("/buscar/videojuego")
    public ResponseEntity<List<ReservaDTO>> buscarPorVideojuego(@RequestParam Long videojuegoId) {
        return ResponseEntity.ok(service.findByVideojuego(videojuegoId));
    }

    // GET /api/v1/reservas/buscar/fechas?desde=2025-05-01&hasta=2025-05-31
    @GetMapping("/buscar/fechas")
    public ResponseEntity<List<ReservaDTO>> buscarPorFechas(@RequestParam LocalDate desde,
                                                            @RequestParam LocalDate hasta) {
        return ResponseEntity.ok(service.findByFechas(desde, hasta));
    }
}