CREATE TABLE IF NOT EXISTS reservas (
    id             BIGINT      AUTO_INCREMENT PRIMARY KEY,
    fecha_reserva  DATE        NOT NULL,
    estado         VARCHAR(50) NOT NULL,
    usuario_id     BIGINT      NOT NULL,
    videojuego_id  BIGINT      NOT NULL
    );