INSERT INTO reservas (fecha_reserva, estado, usuario_id, videojuego_id) VALUES
('2025-05-12', 'PENDIENTE',  2, 5),
('2025-05-13', 'CONFIRMADA', 3, 1),
('2025-05-14', 'CANCELADA',  4, 3),
('2025-05-15', 'PENDIENTE',  5, 7),
('2025-05-16', 'CONFIRMADA', 2, 6);