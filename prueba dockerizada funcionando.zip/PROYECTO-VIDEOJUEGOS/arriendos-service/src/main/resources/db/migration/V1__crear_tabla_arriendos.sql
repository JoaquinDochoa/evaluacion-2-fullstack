CREATE TABLE IF NOT EXISTS arriendos (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    fecha           DATE   NOT NULL,
    usuario_id      BIGINT NOT NULL,
    videojuego_id   BIGINT NOT NULL
);