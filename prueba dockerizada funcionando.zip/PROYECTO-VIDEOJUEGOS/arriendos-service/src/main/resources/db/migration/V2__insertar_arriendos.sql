INSERT INTO arriendos (fecha, usuario_id, videojuego_id) VALUES
('2025-05-01', 2, 1),
('2025-05-03', 3, 3),
('2025-05-05', 4, 2),
('2025-05-07', 2, 4),
('2025-05-10', 5, 6);