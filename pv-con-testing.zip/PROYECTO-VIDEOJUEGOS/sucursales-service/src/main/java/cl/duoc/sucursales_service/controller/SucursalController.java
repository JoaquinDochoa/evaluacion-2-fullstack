package cl.duoc.sucursales_service.controller;

import cl.duoc.sucursales_service.exception.ErrorResponse;
import cl.duoc.sucursales_service.model.Sucursal;
import cl.duoc.sucursales_service.service.SucursalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/sucursales")
@Tag(name = "Sucursales", description = "Controlador para la gestión de sucursales de la tienda de videojuegos.")
public class SucursalController {

    @Autowired
    private SucursalService service;

    // ── CRUD ──────────────────────────────────────────────

    @GetMapping
    @Operation(
            summary = "Listar sucursales",
            description = "Método para listar todas las sucursales registradas en la base de datos."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado completo de sucursales",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Sucursal.class)))
    )
    public ResponseEntity<List<Sucursal>> listar() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Buscar sucursal por ID",
            description = "Método para buscar una sucursal a través de su ID numérico."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Sucursal encontrada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = Sucursal.class))
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Sucursal no encontrada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Solicitud mal enviada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<Sucursal> buscar(
            @PathVariable
            @Parameter(description = "ID de la sucursal", example = "1", required = true)
            Long id) {
        Sucursal sucursal = service.findById(id);
        if (sucursal == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(sucursal);
    }

    @PostMapping
    @Operation(
            summary = "Registrar sucursal",
            description = "Método para registrar una nueva sucursal. El teléfono debe tener entre 8 y 12 caracteres."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Sucursal registrada correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = Sucursal.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos inválidos (teléfono fuera de rango, campos vacíos, etc.)",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<Sucursal> guardar(@Valid @RequestBody Sucursal sucursal) {
        return ResponseEntity.ok(service.save(sucursal));
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar sucursal",
            description = "Método para actualizar los datos de una sucursal existente."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Sucursal actualizada correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = Sucursal.class))
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Sucursal no encontrada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<Sucursal> actualizar(
            @PathVariable
            @Parameter(description = "ID de la sucursal a actualizar", example = "1", required = true)
            Long id,
            @Valid @RequestBody Sucursal sucursal) {
        Sucursal sucursalActualizada = service.update(id, sucursal);
        if (sucursalActualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(sucursalActualizada);
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar sucursal",
            description = "Método para eliminar una sucursal del sistema por su ID."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Sucursal eliminada correctamente"),
            @ApiResponse(
                    responseCode = "404",
                    description = "Sucursal no encontrada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<Void> eliminar(
            @PathVariable
            @Parameter(description = "ID de la sucursal a eliminar", example = "1", required = true)
            Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}