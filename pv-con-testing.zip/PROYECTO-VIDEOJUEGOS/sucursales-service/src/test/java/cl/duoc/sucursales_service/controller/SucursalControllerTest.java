package cl.duoc.sucursales_service.controller;

import cl.duoc.sucursales_service.model.Sucursal;
import cl.duoc.sucursales_service.service.SucursalService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(SucursalController.class)
@DisplayName("SucursalController - Pruebas unitarias")
class SucursalControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SucursalService service;

    @Autowired
    private ObjectMapper objectMapper;

    private Sucursal sucursal;

    @BeforeEach
    void setUp() {
        sucursal = Sucursal.builder()
                .id(1L)
                .nombre("Sucursal Centro")
                .direccion("Av. Libertador 123")
                .telefono("56912345678")
                .build();
    }

    // ── GET /api/v1/sucursales ───────────────────────────

    @Test
    @DisplayName("GET /api/v1/sucursales debe retornar 200 con lista de sucursales")
    void listar_retorna200ConLista() throws Exception {
        when(service.findAll()).thenReturn(List.of(sucursal));

        mockMvc.perform(get("/api/v1/sucursales"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].nombre").value("Sucursal Centro"))
                .andExpect(jsonPath("$[0].telefono").value("56912345678"));
    }

    @Test
    @DisplayName("GET /api/v1/sucursales debe retornar 200 con lista vacía")
    void listar_retorna200ListaVacia() throws Exception {
        when(service.findAll()).thenReturn(List.of());

        mockMvc.perform(get("/api/v1/sucursales"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    // ── GET /api/v1/sucursales/{id} ──────────────────────

    @Test
    @DisplayName("GET /api/v1/sucursales/{id} debe retornar 200 cuando existe")
    void buscar_retorna200CuandoExiste() throws Exception {
        when(service.findById(1L)).thenReturn(sucursal);

        mockMvc.perform(get("/api/v1/sucursales/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.nombre").value("Sucursal Centro"))
                .andExpect(jsonPath("$.direccion").value("Av. Libertador 123"));
    }

    @Test
    @DisplayName("GET /api/v1/sucursales/{id} debe retornar 404 cuando service retorna null")
    void buscar_retorna404CuandoNoExiste() throws Exception {
        when(service.findById(99L)).thenReturn(null);

        mockMvc.perform(get("/api/v1/sucursales/99"))
                .andExpect(status().isNotFound());
    }

    // ── POST /api/v1/sucursales ──────────────────────────

    @Test
    @DisplayName("POST /api/v1/sucursales debe retornar 200 con sucursal creada")
    void guardar_retorna200CuandoDatosValidos() throws Exception {
        Sucursal nueva = Sucursal.builder()
                .nombre("Sucursal Norte")
                .direccion("Av. Norte 456")
                .telefono("56998887766")
                .build();

        when(service.save(any(Sucursal.class))).thenReturn(sucursal);

        mockMvc.perform(post("/api/v1/sucursales")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nueva)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Sucursal Centro"));
    }

    @Test
    @DisplayName("POST /api/v1/sucursales debe retornar 400 cuando faltan campos")
    void guardar_retorna400CuandoCamposFaltantes() throws Exception {
        Sucursal invalida = new Sucursal(); // sin campos

        mockMvc.perform(post("/api/v1/sucursales")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalida)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("POST /api/v1/sucursales debe retornar 400 con teléfono muy corto")
    void guardar_retorna400CuandoTelefonoMuyCorto() throws Exception {
        Sucursal invalida = Sucursal.builder()
                .nombre("Sucursal X")
                .direccion("Calle X 1")
                .telefono("123") // menos de 8 caracteres
                .build();

        mockMvc.perform(post("/api/v1/sucursales")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalida)))
                .andExpect(status().isBadRequest());
    }

    // ── PUT /api/v1/sucursales/{id} ──────────────────────

    @Test
    @DisplayName("PUT /api/v1/sucursales/{id} debe retornar 200 con sucursal actualizada")
    void actualizar_retorna200CuandoExiste() throws Exception {
        when(service.update(eq(1L), any(Sucursal.class))).thenReturn(sucursal);

        mockMvc.perform(put("/api/v1/sucursales/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sucursal)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    @DisplayName("PUT /api/v1/sucursales/{id} debe retornar 404 cuando service retorna null")
    void actualizar_retorna404CuandoNoExiste() throws Exception {
        when(service.update(eq(99L), any(Sucursal.class))).thenReturn(null);

        mockMvc.perform(put("/api/v1/sucursales/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sucursal)))
                .andExpect(status().isNotFound());
    }

    // ── DELETE /api/v1/sucursales/{id} ───────────────────

    @Test
    @DisplayName("DELETE /api/v1/sucursales/{id} debe retornar 204 al eliminar")
    void eliminar_retorna204() throws Exception {
        doNothing().when(service).delete(1L);

        mockMvc.perform(delete("/api/v1/sucursales/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("DELETE /api/v1/sucursales/{id} debe retornar 204 incluso si el ID no existe (comportamiento actual del servicio)")
    void eliminar_retorna204AunqueNoExista() throws Exception {
        // SucursalService.delete() llama directamente a repository.deleteById()
        // sin verificar existencia, por lo que no lanza excepción
        doNothing().when(service).delete(99L);

        mockMvc.perform(delete("/api/v1/sucursales/99"))
                .andExpect(status().isNoContent());
    }
}
