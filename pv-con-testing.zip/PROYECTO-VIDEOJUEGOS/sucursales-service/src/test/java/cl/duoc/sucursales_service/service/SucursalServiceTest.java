package cl.duoc.sucursales_service.service;

import cl.duoc.sucursales_service.model.Sucursal;
import cl.duoc.sucursales_service.repository.SucursalRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("SucursalService - Pruebas unitarias")
class SucursalServiceTest {

    @Mock
    private SucursalRepository repository;

    @InjectMocks
    private SucursalService service;

    private Sucursal sucursal;

    @BeforeEach
    void setUp() {
        sucursal = Sucursal.builder()
                .id(1L)
                .nombre("Sucursal Centro")
                .direccion("Av. Libertador 123")
                .telefono("56912345678")
                .build();
    }

    // ── findAll ───────────────────────────────────────────

    @Test
    @DisplayName("findAll() debe retornar lista con todas las sucursales")
    void findAll_retornaListaCompleta() {
        when(repository.findAll()).thenReturn(List.of(sucursal));

        List<Sucursal> resultado = service.findAll();

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getNombre()).isEqualTo("Sucursal Centro");
        verify(repository).findAll();
    }

    @Test
    @DisplayName("findAll() debe retornar lista vacía cuando no hay sucursales")
    void findAll_retornaListaVacia() {
        when(repository.findAll()).thenReturn(List.of());

        List<Sucursal> resultado = service.findAll();

        assertThat(resultado).isEmpty();
    }

    // ── findById ──────────────────────────────────────────

    @Test
    @DisplayName("findById() debe retornar la sucursal cuando existe")
    void findById_retornaSucursalCuandoExiste() {
        when(repository.findById(1L)).thenReturn(Optional.of(sucursal));

        Sucursal resultado = service.findById(1L);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getId()).isEqualTo(1L);
        assertThat(resultado.getNombre()).isEqualTo("Sucursal Centro");
    }

    @Test
    @DisplayName("findById() debe retornar null cuando la sucursal no existe")
    void findById_retornaNullCuandoNoExiste() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        Sucursal resultado = service.findById(99L);

        assertThat(resultado).isNull();
    }

    // ── save ─────────────────────────────────────────────

    @Test
    @DisplayName("save() debe guardar y retornar la sucursal persistida")
    void save_guardaYRetornaSucursal() {
        when(repository.save(sucursal)).thenReturn(sucursal);

        Sucursal resultado = service.save(sucursal);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getNombre()).isEqualTo("Sucursal Centro");
        assertThat(resultado.getTelefono()).isEqualTo("56912345678");
        verify(repository).save(sucursal);
    }

    // ── delete ────────────────────────────────────────────

    @Test
    @DisplayName("delete() debe invocar deleteById en el repositorio")
    void delete_invocaDeleteById() {
        doNothing().when(repository).deleteById(1L);

        service.delete(1L);

        verify(repository).deleteById(1L);
    }

    // ── update ────────────────────────────────────────────

    @Test
    @DisplayName("update() debe actualizar los campos y retornar la sucursal modificada")
    void update_actualizaSucursalCuandoExiste() {
        Sucursal datosActualizados = Sucursal.builder()
                .nombre("Sucursal Norte")
                .direccion("Av. Norte 456")
                .telefono("56998765432")
                .build();

        when(repository.findById(1L)).thenReturn(Optional.of(sucursal));
        when(repository.save(any(Sucursal.class))).thenAnswer(inv -> inv.getArgument(0));

        Sucursal resultado = service.update(1L, datosActualizados);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getNombre()).isEqualTo("Sucursal Norte");
        assertThat(resultado.getDireccion()).isEqualTo("Av. Norte 456");
        assertThat(resultado.getTelefono()).isEqualTo("56998765432");
        verify(repository).save(any(Sucursal.class));
    }

    @Test
    @DisplayName("update() debe retornar null cuando la sucursal no existe")
    void update_retornaNullCuandoNoExiste() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        Sucursal resultado = service.update(99L, sucursal);

        assertThat(resultado).isNull();
        verify(repository, never()).save(any());
    }

    @Test
    @DisplayName("update() solo debe modificar los campos nombre, dirección y teléfono")
    void update_modificaSoloCamposPermitidos() {
        Sucursal nuevos = Sucursal.builder()
                .nombre("Sucursal Sur")
                .direccion("Av. Sur 789")
                .telefono("56911223344")
                .build();

        when(repository.findById(1L)).thenReturn(Optional.of(sucursal));
        when(repository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        Sucursal resultado = service.update(1L, nuevos);

        // El ID original no debe cambiar
        assertThat(resultado.getId()).isEqualTo(1L);
        assertThat(resultado.getNombre()).isEqualTo("Sucursal Sur");
    }
}
