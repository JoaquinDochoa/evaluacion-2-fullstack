package cl.duoc.usuarios_service.controller;

import cl.duoc.usuarios_service.dto.UsuarioDTO;
import cl.duoc.usuarios_service.exception.ErrorResponse;
import cl.duoc.usuarios_service.model.Usuario;
import cl.duoc.usuarios_service.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/usuarios")
@Tag(name = "Usuarios", description = "Controlador para la gestión de usuarios del sistema de arriendo de videojuegos."+
        "Documentación hecha por Joaquín Ochoa")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    // ── CRUD ──────────────────────────────────────────────

    @GetMapping
    @Operation(
            summary = "Listar usuarios",
            description = "Método para listar todos los usuarios registrados en la base de datos."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado completo de usuarios",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = UsuarioDTO.class)))
    )
    public ResponseEntity<List<UsuarioDTO>> listar() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Buscar usuario por ID",
            description = "Método para buscar un usuario a través de su ID numérico."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = UsuarioDTO.class))
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Usuario no encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Solicitud mal enviada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<UsuarioDTO> buscar(
            @PathVariable
            @Parameter(description = "ID del usuario", example = "1", required = true)
            Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    @Operation(
            summary = "Registrar usuario",
            description = "Método para registrar un nuevo usuario. El rol debe ser ADMIN, EMPLEADO o CLIENTE."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario registrado correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = UsuarioDTO.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos inválidos (correo mal formateado, campos vacíos, contraseña corta, etc.)",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<UsuarioDTO> guardar(@Valid @RequestBody Usuario usuario) {
        return ResponseEntity.ok(service.save(usuario));
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar usuario",
            description = "Método para actualizar los datos de un usuario existente."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario actualizado correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = UsuarioDTO.class))
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Usuario no encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<UsuarioDTO> actualizar(
            @PathVariable
            @Parameter(description = "ID del usuario a actualizar", example = "1", required = true)
            Long id,
            @Valid @RequestBody Usuario usuario) {
        return ResponseEntity.ok(service.update(id, usuario));
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar usuario",
            description = "Método para eliminar un usuario del sistema por su ID."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Usuario eliminado correctamente"),
            @ApiResponse(
                    responseCode = "404",
                    description = "Usuario no encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<Void> eliminar(
            @PathVariable
            @Parameter(description = "ID del usuario a eliminar", example = "1", required = true)
            Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // ── REPORTES ──────────────────────────────────────────

    @GetMapping("/buscar/correo")
    @Operation(
            summary = "Buscar usuario por correo",
            description = "Busca un usuario exacto según su correo electrónico."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = UsuarioDTO.class))
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "No existe usuario con ese correo",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<UsuarioDTO> buscarPorCorreo(
            @RequestParam
            @Parameter(description = "Correo electrónico del usuario", example = "carlos.mendoza@gmail.com", required = true)
            String correo) {
        return ResponseEntity.ok(service.findByCorreo(correo));
    }

    @GetMapping("/buscar/rol")
    @Operation(
            summary = "Buscar usuarios por rol",
            description = "Filtra usuarios según su rol en el sistema. Valores aceptados: ADMIN, EMPLEADO, CLIENTE."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de usuarios con ese rol",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = UsuarioDTO.class)))
    )
    public ResponseEntity<List<UsuarioDTO>> buscarPorRol(
            @RequestParam
            @Parameter(description = "Rol del usuario", example = "CLIENTE", required = true)
            String rol) {
        return ResponseEntity.ok(service.findByRol(rol));
    }

    @GetMapping("/buscar/nombre")
    @Operation(
            summary = "Buscar usuarios por nombre",
            description = "Búsqueda parcial e insensible a mayúsculas sobre el nombre del usuario."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de usuarios que coinciden con el nombre",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = UsuarioDTO.class)))
    )
    public ResponseEntity<List<UsuarioDTO>> buscarPorNombre(
            @RequestParam
            @Parameter(description = "Texto a buscar en el nombre del usuario", example = "carlos", required = true)
            String nombre) {
        return ResponseEntity.ok(service.findByNombre(nombre));
    }
}