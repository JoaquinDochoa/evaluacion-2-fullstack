package cl.duoc.usuarios_service;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
@OpenAPIDefinition(
		info = @Info(
				title = "ARRIENDO DE VIDEOJUEGOS",
				description = "DESCRIPTION:" +
						"Documentación hecha por Joaquín Ochoa",
				version = "1.0.1",
				contact = @Contact(
						name =
								"contact_name"
						,
						email = "joa.ochoa@duocuc.cl"
				)
		)
)
@SpringBootApplication
@EnableDiscoveryClient
public class UsuariosServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsuariosServiceApplication.class, args);
	}
}