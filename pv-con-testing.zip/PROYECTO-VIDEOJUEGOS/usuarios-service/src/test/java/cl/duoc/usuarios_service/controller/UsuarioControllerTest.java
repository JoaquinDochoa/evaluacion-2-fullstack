package cl.duoc.usuarios_service.controller;

import cl.duoc.usuarios_service.dto.UsuarioDTO;
import cl.duoc.usuarios_service.exception.UsuarioNotFoundException;
import cl.duoc.usuarios_service.model.Usuario;
import cl.duoc.usuarios_service.service.UsuarioService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UsuarioController.class)
@DisplayName("UsuarioController - Pruebas unitarias")
class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService service;

    @Autowired
    private ObjectMapper objectMapper;

    private UsuarioDTO usuarioDTO;
    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuarioDTO = UsuarioDTO.builder()
                .id(1L)
                .nombre("Carlos Mendoza")
                .correo("carlos.mendoza@gmail.com")
                .rol("CLIENTE")
                .build();

        usuario = Usuario.builder()
                .nombre("Carlos Mendoza")
                .correo("carlos.mendoza@gmail.com")
                .password("1234")
                .rol("CLIENTE")
                .build();
    }

    // ── GET /api/v1/usuarios ─────────────────────────────

    @Test
    @DisplayName("GET /api/v1/usuarios debe retornar 200 con lista de usuarios")
    void listar_retorna200ConLista() throws Exception {
        when(service.findAll()).thenReturn(List.of(usuarioDTO));

        mockMvc.perform(get("/api/v1/usuarios"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].nombre").value("Carlos Mendoza"))
                .andExpect(jsonPath("$[0].rol").value("CLIENTE"));
    }

    @Test
    @DisplayName("GET /api/v1/usuarios debe retornar 200 con lista vacía")
    void listar_retorna200ListaVacia() throws Exception {
        when(service.findAll()).thenReturn(List.of());

        mockMvc.perform(get("/api/v1/usuarios"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    // ── GET /api/v1/usuarios/{id} ────────────────────────

    @Test
    @DisplayName("GET /api/v1/usuarios/{id} debe retornar 200 cuando existe")
    void buscar_retorna200CuandoExiste() throws Exception {
        when(service.findById(1L)).thenReturn(usuarioDTO);

        mockMvc.perform(get("/api/v1/usuarios/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.correo").value("carlos.mendoza@gmail.com"));
    }

    @Test
    @DisplayName("GET /api/v1/usuarios/{id} debe retornar 404 cuando no existe")
    void buscar_retorna404CuandoNoExiste() throws Exception {
        when(service.findById(99L)).thenThrow(new UsuarioNotFoundException(99L));

        mockMvc.perform(get("/api/v1/usuarios/99"))
                .andExpect(status().isNotFound());
    }

    // ── POST /api/v1/usuarios ────────────────────────────

    @Test
    @DisplayName("POST /api/v1/usuarios debe retornar 200 con usuario creado")
    void guardar_retorna200CuandoDatosValidos() throws Exception {
        when(service.save(any(Usuario.class))).thenReturn(usuarioDTO);

        mockMvc.perform(post("/api/v1/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(usuario)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Carlos Mendoza"))
                .andExpect(jsonPath("$.correo").value("carlos.mendoza@gmail.com"));
    }

    @Test
    @DisplayName("POST /api/v1/usuarios debe retornar 400 cuando faltan campos")
    void guardar_retorna400CuandoCamposFaltantes() throws Exception {
        Usuario invalido = new Usuario(); // sin campos

        mockMvc.perform(post("/api/v1/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalido)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("POST /api/v1/usuarios debe retornar 400 con correo inválido")
    void guardar_retorna400CuandoCorreoInvalido() throws Exception {
        usuario.setCorreo("no-es-un-correo");

        mockMvc.perform(post("/api/v1/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(usuario)))
                .andExpect(status().isBadRequest());
    }

    // ── PUT /api/v1/usuarios/{id} ────────────────────────

    @Test
    @DisplayName("PUT /api/v1/usuarios/{id} debe retornar 200 con usuario actualizado")
    void actualizar_retorna200CuandoExiste() throws Exception {
        when(service.update(eq(1L), any(Usuario.class))).thenReturn(usuarioDTO);

        mockMvc.perform(put("/api/v1/usuarios/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(usuario)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Carlos Mendoza"));
    }

    @Test
    @DisplayName("PUT /api/v1/usuarios/{id} debe retornar 404 cuando no existe")
    void actualizar_retorna404CuandoNoExiste() throws Exception {
        when(service.update(eq(99L), any(Usuario.class)))
                .thenThrow(new UsuarioNotFoundException(99L));

        mockMvc.perform(put("/api/v1/usuarios/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(usuario)))
                .andExpect(status().isNotFound());
    }

    // ── DELETE /api/v1/usuarios/{id} ─────────────────────

    @Test
    @DisplayName("DELETE /api/v1/usuarios/{id} debe retornar 204 cuando existe")
    void eliminar_retorna204CuandoExiste() throws Exception {
        doNothing().when(service).delete(1L);

        mockMvc.perform(delete("/api/v1/usuarios/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("DELETE /api/v1/usuarios/{id} debe retornar 404 cuando no existe")
    void eliminar_retorna404CuandoNoExiste() throws Exception {
        doThrow(new UsuarioNotFoundException(99L)).when(service).delete(99L);

        mockMvc.perform(delete("/api/v1/usuarios/99"))
                .andExpect(status().isNotFound());
    }

    // ── GET /api/v1/usuarios/buscar/correo ───────────────

    @Test
    @DisplayName("GET /buscar/correo debe retornar 200 con el usuario encontrado")
    void buscarPorCorreo_retorna200() throws Exception {
        when(service.findByCorreo("carlos.mendoza@gmail.com")).thenReturn(usuarioDTO);

        mockMvc.perform(get("/api/v1/usuarios/buscar/correo")
                        .param("correo", "carlos.mendoza@gmail.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.correo").value("carlos.mendoza@gmail.com"));
    }

    @Test
    @DisplayName("GET /buscar/correo debe retornar 404 cuando el correo no existe")
    void buscarPorCorreo_retorna404CuandoNoExiste() throws Exception {
        when(service.findByCorreo("noexiste@gmail.com"))
                .thenThrow(new UsuarioNotFoundException("noexiste@gmail.com"));

        mockMvc.perform(get("/api/v1/usuarios/buscar/correo")
                        .param("correo", "noexiste@gmail.com"))
                .andExpect(status().isNotFound());
    }

    // ── GET /api/v1/usuarios/buscar/rol ──────────────────

    @Test
    @DisplayName("GET /buscar/rol debe retornar 200 con lista de usuarios por rol")
    void buscarPorRol_retorna200() throws Exception {
        when(service.findByRol("CLIENTE")).thenReturn(List.of(usuarioDTO));

        mockMvc.perform(get("/api/v1/usuarios/buscar/rol")
                        .param("rol", "CLIENTE"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].rol").value("CLIENTE"));
    }

    // ── GET /api/v1/usuarios/buscar/nombre ───────────────

    @Test
    @DisplayName("GET /buscar/nombre debe retornar 200 con coincidencias por nombre")
    void buscarPorNombre_retorna200() throws Exception {
        when(service.findByNombre("carlos")).thenReturn(List.of(usuarioDTO));

        mockMvc.perform(get("/api/v1/usuarios/buscar/nombre")
                        .param("nombre", "carlos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }
}
