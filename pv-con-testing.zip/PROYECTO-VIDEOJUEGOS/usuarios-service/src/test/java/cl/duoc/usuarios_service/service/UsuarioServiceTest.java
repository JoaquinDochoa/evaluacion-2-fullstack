package cl.duoc.usuarios_service.service;

import cl.duoc.usuarios_service.dto.UsuarioDTO;
import cl.duoc.usuarios_service.exception.UsuarioNotFoundException;
import cl.duoc.usuarios_service.mapper.UsuarioMapper;
import cl.duoc.usuarios_service.model.Usuario;
import cl.duoc.usuarios_service.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("UsuarioService - Pruebas unitarias")
class UsuarioServiceTest {

    @Mock
    private UsuarioRepository repository;

    @Mock
    private UsuarioMapper mapper;

    @InjectMocks
    private UsuarioService service;

    private Usuario usuario;
    private UsuarioDTO usuarioDTO;

    @BeforeEach
    void setUp() {
        usuario = Usuario.builder()
                .id(1L)
                .nombre("Carlos Mendoza")
                .correo("carlos.mendoza@gmail.com")
                .password("1234")
                .rol("CLIENTE")
                .build();

        usuarioDTO = UsuarioDTO.builder()
                .id(1L)
                .nombre("Carlos Mendoza")
                .correo("carlos.mendoza@gmail.com")
                .rol("CLIENTE")
                .build();
    }

    // ── findAll ───────────────────────────────────────────

    @Test
    @DisplayName("findAll() debe retornar lista con todos los usuarios")
    void findAll_retornaListaCompleta() {
        when(repository.findAll()).thenReturn(List.of(usuario));
        when(mapper.toDTO(usuario)).thenReturn(usuarioDTO);

        List<UsuarioDTO> resultado = service.findAll();

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getNombre()).isEqualTo("Carlos Mendoza");
        verify(repository).findAll();
    }

    @Test
    @DisplayName("findAll() debe retornar lista vacía cuando no hay usuarios")
    void findAll_retornaListaVacia() {
        when(repository.findAll()).thenReturn(List.of());

        List<UsuarioDTO> resultado = service.findAll();

        assertThat(resultado).isEmpty();
    }

    // ── findById ──────────────────────────────────────────

    @Test
    @DisplayName("findById() debe retornar el usuario cuando existe")
    void findById_retornaUsuarioCuandoExiste() {
        when(repository.findById(1L)).thenReturn(Optional.of(usuario));
        when(mapper.toDTO(usuario)).thenReturn(usuarioDTO);

        UsuarioDTO resultado = service.findById(1L);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getId()).isEqualTo(1L);
        assertThat(resultado.getCorreo()).isEqualTo("carlos.mendoza@gmail.com");
    }

    @Test
    @DisplayName("findById() debe lanzar UsuarioNotFoundException cuando no existe")
    void findById_lanzaExcepcionCuandoNoExiste() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.findById(99L))
                .isInstanceOf(UsuarioNotFoundException.class);
    }

    // ── save ─────────────────────────────────────────────

    @Test
    @DisplayName("save() debe guardar y retornar el DTO del usuario creado")
    void save_guardaYRetornaDTO() {
        when(repository.save(usuario)).thenReturn(usuario);
        when(mapper.toDTO(usuario)).thenReturn(usuarioDTO);

        UsuarioDTO resultado = service.save(usuario);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getNombre()).isEqualTo("Carlos Mendoza");
        verify(repository).save(usuario);
    }

    // ── delete ────────────────────────────────────────────

    @Test
    @DisplayName("delete() debe eliminar el usuario cuando existe")
    void delete_eliminaCuandoExiste() {
        when(repository.existsById(1L)).thenReturn(true);

        service.delete(1L);

        verify(repository).deleteById(1L);
    }

    @Test
    @DisplayName("delete() debe lanzar UsuarioNotFoundException cuando no existe")
    void delete_lanzaExcepcionCuandoNoExiste() {
        when(repository.existsById(99L)).thenReturn(false);

        assertThatThrownBy(() -> service.delete(99L))
                .isInstanceOf(UsuarioNotFoundException.class);

        verify(repository, never()).deleteById(any());
    }

    // ── update ────────────────────────────────────────────

    @Test
    @DisplayName("update() debe actualizar los campos del usuario y retornar DTO")
    void update_actualizaCamposCorrectamente() {
        Usuario datosActualizados = Usuario.builder()
                .nombre("Carlos M. Actualizado")
                .correo("nuevo@gmail.com")
                .password("abcd")
                .rol("ADMIN")
                .build();

        when(repository.findById(1L)).thenReturn(Optional.of(usuario));
        when(repository.save(any())).thenReturn(usuario);
        when(mapper.toDTO(any())).thenReturn(usuarioDTO);

        UsuarioDTO resultado = service.update(1L, datosActualizados);

        assertThat(resultado).isNotNull();
        verify(repository).save(any(Usuario.class));
    }

    @Test
    @DisplayName("update() debe lanzar excepción cuando el usuario no existe")
    void update_lanzaExcepcionCuandoNoExiste() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.update(99L, usuario))
                .isInstanceOf(UsuarioNotFoundException.class);
    }

    // ── Reportes ─────────────────────────────────────────

    @Test
    @DisplayName("findByCorreo() debe retornar el usuario con ese correo")
    void findByCorreo_retornaUsuarioCorrecto() {
        when(repository.findByCorreo("carlos.mendoza@gmail.com")).thenReturn(Optional.of(usuario));
        when(mapper.toDTO(usuario)).thenReturn(usuarioDTO);

        UsuarioDTO resultado = service.findByCorreo("carlos.mendoza@gmail.com");

        assertThat(resultado.getCorreo()).isEqualTo("carlos.mendoza@gmail.com");
    }

    @Test
    @DisplayName("findByCorreo() debe lanzar excepción si el correo no existe")
    void findByCorreo_lanzaExcepcionCuandoNoExiste() {
        when(repository.findByCorreo("noexiste@gmail.com")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.findByCorreo("noexiste@gmail.com"))
                .isInstanceOf(UsuarioNotFoundException.class);
    }

    @Test
    @DisplayName("findByRol() debe retornar usuarios con el rol indicado")
    void findByRol_retornaUsuariosConRol() {
        when(repository.findByRol("CLIENTE")).thenReturn(List.of(usuario));
        when(mapper.toDTO(usuario)).thenReturn(usuarioDTO);

        List<UsuarioDTO> resultado = service.findByRol("CLIENTE");

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getRol()).isEqualTo("CLIENTE");
    }

    @Test
    @DisplayName("findByNombre() debe retornar coincidencias parciales por nombre")
    void findByNombre_retornaCoincidencias() {
        when(repository.findByNombreContainingIgnoreCase("carlos")).thenReturn(List.of(usuario));
        when(mapper.toDTO(usuario)).thenReturn(usuarioDTO);

        List<UsuarioDTO> resultado = service.findByNombre("carlos");

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getNombre()).containsIgnoringCase("carlos");
    }
}
