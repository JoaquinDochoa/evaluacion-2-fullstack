package cl.duoc.videojuegos_service.controller;

import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.exception.ErrorResponse;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.service.VideojuegoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/videojuegos")
@Tag(name = "Videojuegos", description = "Controlador para la gestión del catálogo de videojuegos en arriendo." +
        "Documentación hecha por Joaquín Ochoa")
public class VideojuegoController {

    @Autowired
    private VideojuegoService service;

    // ── CRUD ──────────────────────────────────────────────

    @GetMapping
    @Operation(
            summary = "Listar videojuegos",
            description = "Método para listar todos los videojuegos disponibles en la base de datos."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado completo de videojuegos",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VideojuegoDTO.class)))
    )
    public ResponseEntity<List<VideojuegoDTO>> listar() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Buscar videojuego por ID",
            description = "Método para buscar un videojuego a través de su ID numérico."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Videojuego encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = VideojuegoDTO.class))
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Videojuego no encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Solicitud mal enviada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<VideojuegoDTO> buscar(
            @PathVariable
            @Parameter(description = "ID del videojuego", example = "1", required = true)
            Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    @Operation(
            summary = "Registrar videojuego",
            description = "Método para registrar un nuevo videojuego. La plataforma debe ser PS5, PC o XBOX SERIES X."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Videojuego registrado correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = VideojuegoDTO.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos inválidos en la solicitud",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<VideojuegoDTO> guardar(@Valid @RequestBody Videojuego videojuego) {
        return ResponseEntity.ok(service.save(videojuego));
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar videojuego",
            description = "Método para actualizar los datos de un videojuego existente."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Videojuego actualizado correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = VideojuegoDTO.class))
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Videojuego no encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<VideojuegoDTO> actualizar(
            @PathVariable
            @Parameter(description = "ID del videojuego a actualizar", example = "1", required = true)
            Long id,
            @Valid @RequestBody Videojuego videojuego) {
        return ResponseEntity.ok(service.update(id, videojuego));
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar videojuego",
            description = "Método para eliminar un videojuego del catálogo por su ID."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Videojuego eliminado correctamente"),
            @ApiResponse(
                    responseCode = "404",
                    description = "Videojuego no encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<Void> eliminar(
            @PathVariable
            @Parameter(description = "ID del videojuego a eliminar", example = "1", required = true)
            Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // ── REPORTES ──────────────────────────────────────────

    @GetMapping("/buscar/plataforma")
    @Operation(
            summary = "Buscar por plataforma",
            description = "Filtra videojuegos según la plataforma. Valores aceptados: PS5, PC, XBOX SERIES X."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Listado de videojuegos filtrados por plataforma",
                    content = @Content(
                            mediaType = "application/json",
                            array = @ArraySchema(schema = @Schema(implementation = VideojuegoDTO.class)))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Plataforma no válida",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<List<VideojuegoDTO>> buscarPorPlataforma(
            @RequestParam
            @Parameter(description = "Nombre de la plataforma", example = "PS5", required = true)
            String plataforma) {
        return ResponseEntity.ok(service.findByPlataforma(plataforma));
    }

    @GetMapping("/buscar/categoria")
    @Operation(
            summary = "Buscar por categoría",
            description = "Filtra videojuegos según el ID de categoría."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de videojuegos por categoría",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VideojuegoDTO.class)))
    )
    public ResponseEntity<List<VideojuegoDTO>> buscarPorCategoria(
            @RequestParam
            @Parameter(description = "ID de la categoría", example = "2", required = true)
            Long categoriaId) {
        return ResponseEntity.ok(service.findByCategoria(categoriaId));
    }

    @GetMapping("/buscar/precio")
    @Operation(
            summary = "Buscar por precio máximo",
            description = "Devuelve todos los videojuegos con precio de arriendo menor o igual al valor indicado."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de videojuegos dentro del rango de precio",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VideojuegoDTO.class)))
    )
    public ResponseEntity<List<VideojuegoDTO>> buscarPorPrecio(
            @RequestParam
            @Parameter(description = "Precio máximo de arriendo (en pesos)", example = "3000", required = true)
            Double max) {
        return ResponseEntity.ok(service.findByPrecioMaximo(max));
    }

    @GetMapping("/buscar/titulo")
    @Operation(
            summary = "Buscar por título",
            description = "Búsqueda parcial e insensible a mayúsculas sobre el título del videojuego."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de videojuegos que coinciden con el título",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VideojuegoDTO.class)))
    )
    public ResponseEntity<List<VideojuegoDTO>> buscarPorTitulo(
            @RequestParam
            @Parameter(description = "Texto a buscar en el título", example = "god", required = true)
            String titulo) {
        return ResponseEntity.ok(service.findByTitulo(titulo));
    }

    @GetMapping("/disponibles")
    @Operation(
            summary = "Listar videojuegos disponibles",
            description = "Devuelve únicamente los videojuegos con stock mayor a 0."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de videojuegos con stock disponible",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VideojuegoDTO.class)))
    )
    public ResponseEntity<List<VideojuegoDTO>> disponibles() {
        return ResponseEntity.ok(service.findDisponibles());
    }
}