package cl.duoc.videojuegos_service.controller;

import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.exception.VideojuegoNotFoundException;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.service.VideojuegoService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(VideojuegoController.class)
@DisplayName("VideojuegoController - Pruebas unitarias")
class VideojuegoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private VideojuegoService service;

    @Autowired
    private ObjectMapper objectMapper;

    private VideojuegoDTO videojuegoDTO;
    private Videojuego videojuego;

    @BeforeEach
    void setUp() {
        videojuegoDTO = VideojuegoDTO.builder()
                .id(1L)
                .titulo("God of War")
                .plataforma("PS5")
                .precioArriendo(2500.0)
                .stock(5)
                .build();

        videojuego = Videojuego.builder()
                .titulo("God of War")
                .plataforma("PS5")
                .precioArriendo(2500.0)
                .stock(5)
                .categoriaId(1L)
                .build();
    }

    // ── GET /api/v1/videojuegos ───────────────────────────

    @Test
    @DisplayName("GET /api/v1/videojuegos debe retornar 200 con lista de videojuegos")
    void listar_retorna200ConLista() throws Exception {
        when(service.findAll()).thenReturn(List.of(videojuegoDTO));

        mockMvc.perform(get("/api/v1/videojuegos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].titulo").value("God of War"))
                .andExpect(jsonPath("$[0].plataforma").value("PS5"));
    }

    @Test
    @DisplayName("GET /api/v1/videojuegos debe retornar 200 con lista vacía")
    void listar_retorna200ListaVacia() throws Exception {
        when(service.findAll()).thenReturn(List.of());

        mockMvc.perform(get("/api/v1/videojuegos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    // ── GET /api/v1/videojuegos/{id} ─────────────────────

    @Test
    @DisplayName("GET /api/v1/videojuegos/{id} debe retornar 200 cuando el videojuego existe")
    void buscar_retorna200CuandoExiste() throws Exception {
        when(service.findById(1L)).thenReturn(videojuegoDTO);

        mockMvc.perform(get("/api/v1/videojuegos/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.titulo").value("God of War"));
    }

    @Test
    @DisplayName("GET /api/v1/videojuegos/{id} debe retornar 404 cuando no existe")
    void buscar_retorna404CuandoNoExiste() throws Exception {
        when(service.findById(99L)).thenThrow(new VideojuegoNotFoundException(99L));

        mockMvc.perform(get("/api/v1/videojuegos/99"))
                .andExpect(status().isNotFound());
    }

    // ── POST /api/v1/videojuegos ──────────────────────────

    @Test
    @DisplayName("POST /api/v1/videojuegos debe retornar 200 con videojuego creado")
    void guardar_retorna200CuandoDatosValidos() throws Exception {
        when(service.save(any(Videojuego.class))).thenReturn(videojuegoDTO);

        mockMvc.perform(post("/api/v1/videojuegos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(videojuego)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.titulo").value("God of War"))
                .andExpect(jsonPath("$.plataforma").value("PS5"));
    }

    @Test
    @DisplayName("POST /api/v1/videojuegos debe retornar 400 cuando faltan campos obligatorios")
    void guardar_retorna400CuandoCamposFaltantes() throws Exception {
        Videojuego invalido = new Videojuego(); // sin campos

        mockMvc.perform(post("/api/v1/videojuegos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalido)))
                .andExpect(status().isBadRequest());
    }

    // ── PUT /api/v1/videojuegos/{id} ─────────────────────

    @Test
    @DisplayName("PUT /api/v1/videojuegos/{id} debe retornar 200 con videojuego actualizado")
    void actualizar_retorna200CuandoExiste() throws Exception {
        when(service.update(eq(1L), any(Videojuego.class))).thenReturn(videojuegoDTO);

        mockMvc.perform(put("/api/v1/videojuegos/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(videojuego)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.titulo").value("God of War"));
    }

    @Test
    @DisplayName("PUT /api/v1/videojuegos/{id} debe retornar 404 cuando no existe")
    void actualizar_retorna404CuandoNoExiste() throws Exception {
        when(service.update(eq(99L), any(Videojuego.class)))
                .thenThrow(new VideojuegoNotFoundException(99L));

        mockMvc.perform(put("/api/v1/videojuegos/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(videojuego)))
                .andExpect(status().isNotFound());
    }

    // ── DELETE /api/v1/videojuegos/{id} ──────────────────

    @Test
    @DisplayName("DELETE /api/v1/videojuegos/{id} debe retornar 204 cuando existe")
    void eliminar_retorna204CuandoExiste() throws Exception {
        doNothing().when(service).delete(1L);

        mockMvc.perform(delete("/api/v1/videojuegos/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("DELETE /api/v1/videojuegos/{id} debe retornar 404 cuando no existe")
    void eliminar_retorna404CuandoNoExiste() throws Exception {
        doThrow(new VideojuegoNotFoundException(99L)).when(service).delete(99L);

        mockMvc.perform(delete("/api/v1/videojuegos/99"))
                .andExpect(status().isNotFound());
    }

    // ── GET /api/v1/videojuegos/buscar/plataforma ────────

    @Test
    @DisplayName("GET /buscar/plataforma debe retornar 200 con lista filtrada")
    void buscarPorPlataforma_retorna200() throws Exception {
        when(service.findByPlataforma("PS5")).thenReturn(List.of(videojuegoDTO));

        mockMvc.perform(get("/api/v1/videojuegos/buscar/plataforma")
                        .param("plataforma", "PS5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].plataforma").value("PS5"));
    }

    // ── GET /api/v1/videojuegos/buscar/precio ────────────

    @Test
    @DisplayName("GET /buscar/precio debe retornar 200 con videojuegos en rango")
    void buscarPorPrecio_retorna200() throws Exception {
        when(service.findByPrecioMaximo(3000.0)).thenReturn(List.of(videojuegoDTO));

        mockMvc.perform(get("/api/v1/videojuegos/buscar/precio")
                        .param("max", "3000.0"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }

    // ── GET /api/v1/videojuegos/disponibles ──────────────

    @Test
    @DisplayName("GET /disponibles debe retornar 200 con videojuegos con stock")
    void disponibles_retorna200() throws Exception {
        when(service.findDisponibles()).thenReturn(List.of(videojuegoDTO));

        mockMvc.perform(get("/api/v1/videojuegos/disponibles"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }

    // ── GET /api/v1/videojuegos/buscar/titulo ────────────

    @Test
    @DisplayName("GET /buscar/titulo debe retornar 200 con coincidencias")
    void buscarPorTitulo_retorna200() throws Exception {
        when(service.findByTitulo("god")).thenReturn(List.of(videojuegoDTO));

        mockMvc.perform(get("/api/v1/videojuegos/buscar/titulo")
                        .param("titulo", "god"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].titulo").value("God of War"));
    }
}
