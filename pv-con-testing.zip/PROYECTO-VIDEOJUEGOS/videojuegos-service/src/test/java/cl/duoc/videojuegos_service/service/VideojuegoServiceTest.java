package cl.duoc.videojuegos_service.service;

import cl.duoc.videojuegos_service.clients.CategoriaFeign;
import cl.duoc.videojuegos_service.dto.CategoriaDTO;
import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.exception.VideojuegoNotFoundException;
import cl.duoc.videojuegos_service.mapper.VideojuegoMapper;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.repository.VideojuegoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("VideojuegoService - Pruebas unitarias")
class VideojuegoServiceTest {

    @Mock
    private VideojuegoRepository repository;

    @Mock
    private CategoriaFeign categoriaFeign;

    @Mock
    private VideojuegoMapper mapper;

    @InjectMocks
    private VideojuegoService service;

    private Videojuego videojuego;
    private VideojuegoDTO videojuegoDTO;

    @BeforeEach
    void setUp() {
        videojuego = Videojuego.builder()
                .id(1L)
                .titulo("God of War")
                .plataforma("PS5")
                .precioArriendo(2500.0)
                .stock(5)
                .categoriaId(1L)
                .build();

        videojuegoDTO = VideojuegoDTO.builder()
                .id(1L)
                .titulo("God of War")
                .plataforma("PS5")
                .precioArriendo(2500.0)
                .stock(5)
                .build();
    }

    // ── findAll ───────────────────────────────────────────

    @Test
    @DisplayName("findAll() debe retornar lista de todos los videojuegos")
    void findAll_retornaListaCompleta() {
        when(repository.findAll()).thenReturn(List.of(videojuego));
        when(mapper.toDTO(videojuego)).thenReturn(videojuegoDTO);

        List<VideojuegoDTO> resultado = service.findAll();

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getTitulo()).isEqualTo("God of War");
        verify(repository).findAll();
    }

    @Test
    @DisplayName("findAll() debe retornar lista vacía cuando no hay videojuegos")
    void findAll_retornaListaVacia() {
        when(repository.findAll()).thenReturn(List.of());

        List<VideojuegoDTO> resultado = service.findAll();

        assertThat(resultado).isEmpty();
    }

    // ── findById ──────────────────────────────────────────

    @Test
    @DisplayName("findById() debe retornar el videojuego con categoría enriquecida")
    void findById_retornaVideojuegoConCategoria() {
        CategoriaDTO categoriaDTO = new CategoriaDTO(1L, "Acción");
        when(repository.findById(1L)).thenReturn(Optional.of(videojuego));
        when(mapper.toDTO(videojuego)).thenReturn(videojuegoDTO);
        when(categoriaFeign.buscarCategoria(1L)).thenReturn(categoriaDTO);

        VideojuegoDTO resultado = service.findById(1L);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getCategoria()).isEqualTo(categoriaDTO);
        verify(categoriaFeign).buscarCategoria(1L);
    }

    @Test
    @DisplayName("findById() debe lanzar VideojuegoNotFoundException cuando el ID no existe")
    void findById_lanzaExcepcionCuandoNoExiste() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.findById(99L))
                .isInstanceOf(VideojuegoNotFoundException.class);
    }

    // ── save ─────────────────────────────────────────────

    @Test
    @DisplayName("save() debe guardar el videojuego cuando la plataforma es válida")
    void save_guardaVideojuegoCuandoPlataformaValida() {
        when(repository.save(videojuego)).thenReturn(videojuego);
        when(mapper.toDTO(videojuego)).thenReturn(videojuegoDTO);

        VideojuegoDTO resultado = service.save(videojuego);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getTitulo()).isEqualTo("God of War");
        verify(repository).save(videojuego);
    }

    @Test
    @DisplayName("save() debe lanzar IllegalArgumentException con plataforma inválida")
    void save_lanzaExcepcionCuandoPlataformaInvalida() {
        videojuego.setPlataforma("SEGA");

        assertThatThrownBy(() -> service.save(videojuego))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("plataforma");

        verify(repository, never()).save(any());
    }

    @Test
    @DisplayName("save() debe aceptar plataforma en minúsculas (ps5 → PS5)")
    void save_aceptaPlataformaEnMinusculas() {
        videojuego.setPlataforma("ps5");
        when(repository.save(videojuego)).thenReturn(videojuego);
        when(mapper.toDTO(videojuego)).thenReturn(videojuegoDTO);

        assertThatCode(() -> service.save(videojuego)).doesNotThrowAnyException();
    }

    // ── delete ────────────────────────────────────────────

    @Test
    @DisplayName("delete() debe eliminar el videojuego cuando existe")
    void delete_eliminaCuandoExiste() {
        when(repository.existsById(1L)).thenReturn(true);

        service.delete(1L);

        verify(repository).deleteById(1L);
    }

    @Test
    @DisplayName("delete() debe lanzar VideojuegoNotFoundException cuando no existe")
    void delete_lanzaExcepcionCuandoNoExiste() {
        when(repository.existsById(99L)).thenReturn(false);

        assertThatThrownBy(() -> service.delete(99L))
                .isInstanceOf(VideojuegoNotFoundException.class);

        verify(repository, never()).deleteById(any());
    }

    // ── update ────────────────────────────────────────────

    @Test
    @DisplayName("update() debe actualizar y retornar el videojuego modificado")
    void update_actualizaVideojuegoCorrecto() {
        Videojuego datos = Videojuego.builder()
                .titulo("God of War Ragnarok")
                .plataforma("PS5")
                .precioArriendo(3000.0)
                .stock(3)
                .categoriaId(1L)
                .build();

        when(repository.findById(1L)).thenReturn(Optional.of(videojuego));
        when(repository.save(any())).thenReturn(videojuego);
        when(mapper.toDTO(any())).thenReturn(videojuegoDTO);

        VideojuegoDTO resultado = service.update(1L, datos);

        assertThat(resultado).isNotNull();
        verify(repository).save(any());
    }

    @Test
    @DisplayName("update() debe lanzar excepción cuando el videojuego no existe")
    void update_lanzaExcepcionCuandoNoExiste() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.update(99L, videojuego))
                .isInstanceOf(VideojuegoNotFoundException.class);
    }

    @Test
    @DisplayName("update() debe lanzar excepción con plataforma inválida")
    void update_lanzaExcepcionConPlataformaInvalida() {
        videojuego.setPlataforma("ATARI");

        assertThatThrownBy(() -> service.update(1L, videojuego))
                .isInstanceOf(IllegalArgumentException.class);
    }

    // ── Reportes ─────────────────────────────────────────

    @Test
    @DisplayName("findByPlataforma() debe retornar videojuegos de la plataforma indicada")
    void findByPlataforma_retornaVideojuegos() {
        when(repository.findByPlataforma("PS5")).thenReturn(List.of(videojuego));
        when(mapper.toDTO(videojuego)).thenReturn(videojuegoDTO);

        List<VideojuegoDTO> resultado = service.findByPlataforma("PS5");

        assertThat(resultado).hasSize(1);
    }

    @Test
    @DisplayName("findByCategoria() debe retornar videojuegos de la categoría indicada")
    void findByCategoria_retornaVideojuegos() {
        when(repository.findByCategoriaId(1L)).thenReturn(List.of(videojuego));
        when(mapper.toDTO(videojuego)).thenReturn(videojuegoDTO);

        List<VideojuegoDTO> resultado = service.findByCategoria(1L);

        assertThat(resultado).hasSize(1);
    }

    @Test
    @DisplayName("findByPrecioMaximo() debe retornar videojuegos dentro del rango")
    void findByPrecioMaximo_retornaVideojuegosEnRango() {
        when(repository.findByPrecioArriendoLessThanEqual(3000.0)).thenReturn(List.of(videojuego));
        when(mapper.toDTO(videojuego)).thenReturn(videojuegoDTO);

        List<VideojuegoDTO> resultado = service.findByPrecioMaximo(3000.0);

        assertThat(resultado).hasSize(1);
    }

    @Test
    @DisplayName("findByTitulo() debe retornar videojuegos con título coincidente")
    void findByTitulo_retornaCoincidencias() {
        when(repository.findByTituloContainingIgnoreCase("god")).thenReturn(List.of(videojuego));
        when(mapper.toDTO(videojuego)).thenReturn(videojuegoDTO);

        List<VideojuegoDTO> resultado = service.findByTitulo("god");

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getTitulo()).containsIgnoringCase("god");
    }

    @Test
    @DisplayName("findDisponibles() debe retornar sólo videojuegos con stock > 0")
    void findDisponibles_retornaConStock() {
        when(repository.findByStockGreaterThan(0)).thenReturn(List.of(videojuego));
        when(mapper.toDTO(videojuego)).thenReturn(videojuegoDTO);

        List<VideojuegoDTO> resultado = service.findDisponibles();

        assertThat(resultado).isNotEmpty();
        assertThat(resultado.get(0).getStock()).isGreaterThan(0);
    }
}
