package cl.duoc.reservas_service.service;

import cl.duoc.reservas_service.clients.UsuarioFeign;
import cl.duoc.reservas_service.clients.VideojuegoFeign;
import cl.duoc.reservas_service.dto.ReservaDTO;
import cl.duoc.reservas_service.dto.UsuarioDTO;
import cl.duoc.reservas_service.dto.VideojuegoDTO;
import cl.duoc.reservas_service.exception.ReservaNotFoundException;
import cl.duoc.reservas_service.model.Reserva;
import cl.duoc.reservas_service.repository.ReservaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("ReservaService - Pruebas unitarias")
class ReservaServiceTest {

    @Mock
    private ReservaRepository repository;

    @Mock
    private UsuarioFeign usuarioFeign;

    @Mock
    private VideojuegoFeign videojuegoFeign;

    @InjectMocks
    private ReservaService service;

    private Reserva reserva;
    private UsuarioDTO usuarioDTO;
    private VideojuegoDTO videojuegoDTO;

    @BeforeEach
    void setUp() {
        reserva = Reserva.builder()
                .id(1L)
                .fechaReserva(LocalDate.of(2025, 5, 10))
                .estado("PENDIENTE")
                .usuarioId(1L)
                .videojuegoId(1L)
                .build();

        usuarioDTO = UsuarioDTO.builder()
                .id(1L)
                .nombre("Carlos Mendoza")
                .rol("CLIENTE")
                .build();

        videojuegoDTO = VideojuegoDTO.builder()
                .id(1L)
                .titulo("God of War")
                .plataforma("PS5")
                .precioArriendo(2500.0)
                .build();
    }

    // ── findAll ───────────────────────────────────────────

    @Test
    @DisplayName("findAll() debe retornar lista con todas las reservas enriquecidas")
    void findAll_retornaListaCompleta() {
        when(repository.findAll()).thenReturn(List.of(reserva));
        when(usuarioFeign.buscarUsuario(1L)).thenReturn(usuarioDTO);
        when(videojuegoFeign.buscarVideojuego(1L)).thenReturn(videojuegoDTO);

        List<ReservaDTO> resultado = service.findAll();

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getEstado()).isEqualTo("PENDIENTE");
        assertThat(resultado.get(0).getUsuario()).isNotNull();
        assertThat(resultado.get(0).getVideojuego()).isNotNull();
    }

    @Test
    @DisplayName("findAll() debe retornar lista vacía cuando no hay reservas")
    void findAll_retornaListaVacia() {
        when(repository.findAll()).thenReturn(List.of());

        List<ReservaDTO> resultado = service.findAll();

        assertThat(resultado).isEmpty();
    }

    // ── findById ──────────────────────────────────────────

    @Test
    @DisplayName("findById() debe retornar la reserva enriquecida con usuario y videojuego")
    void findById_retornaReservaEnriquecida() {
        when(repository.findById(1L)).thenReturn(Optional.of(reserva));
        when(usuarioFeign.buscarUsuario(1L)).thenReturn(usuarioDTO);
        when(videojuegoFeign.buscarVideojuego(1L)).thenReturn(videojuegoDTO);

        ReservaDTO resultado = service.findById(1L);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getId()).isEqualTo(1L);
        assertThat(resultado.getUsuario().getNombre()).isEqualTo("Carlos Mendoza");
        assertThat(resultado.getVideojuego().getTitulo()).isEqualTo("God of War");
    }

    @Test
    @DisplayName("findById() debe lanzar ReservaNotFoundException cuando no existe")
    void findById_lanzaExcepcionCuandoNoExiste() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.findById(99L))
                .isInstanceOf(ReservaNotFoundException.class);
    }

    // ── save ─────────────────────────────────────────────

    @Test
    @DisplayName("save() debe guardar y retornar la reserva como DTO")
    void save_guardaYRetornaDTO() {
        when(repository.save(reserva)).thenReturn(reserva);
        when(usuarioFeign.buscarUsuario(1L)).thenReturn(usuarioDTO);
        when(videojuegoFeign.buscarVideojuego(1L)).thenReturn(videojuegoDTO);

        ReservaDTO resultado = service.save(reserva);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getEstado()).isEqualTo("PENDIENTE");
        verify(repository).save(reserva);
    }

    // ── delete ────────────────────────────────────────────

    @Test
    @DisplayName("delete() debe eliminar la reserva cuando existe")
    void delete_eliminaCuandoExiste() {
        when(repository.existsById(1L)).thenReturn(true);

        service.delete(1L);

        verify(repository).deleteById(1L);
    }

    @Test
    @DisplayName("delete() debe lanzar ReservaNotFoundException cuando no existe")
    void delete_lanzaExcepcionCuandoNoExiste() {
        when(repository.existsById(99L)).thenReturn(false);

        assertThatThrownBy(() -> service.delete(99L))
                .isInstanceOf(ReservaNotFoundException.class);

        verify(repository, never()).deleteById(any());
    }

    // ── update ────────────────────────────────────────────

    @Test
    @DisplayName("update() debe actualizar y retornar la reserva modificada")
    void update_actualizaReservaCorrecto() {
        Reserva datosActualizados = Reserva.builder()
                .fechaReserva(LocalDate.of(2025, 6, 1))
                .estado("CONFIRMADA")
                .usuarioId(1L)
                .videojuegoId(1L)
                .build();

        when(repository.findById(1L)).thenReturn(Optional.of(reserva));
        when(repository.save(any())).thenReturn(reserva);
        when(usuarioFeign.buscarUsuario(1L)).thenReturn(usuarioDTO);
        when(videojuegoFeign.buscarVideojuego(1L)).thenReturn(videojuegoDTO);

        ReservaDTO resultado = service.update(1L, datosActualizados);

        assertThat(resultado).isNotNull();
        verify(repository).save(any(Reserva.class));
    }

    @Test
    @DisplayName("update() debe lanzar excepción cuando la reserva no existe")
    void update_lanzaExcepcionCuandoNoExiste() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.update(99L, reserva))
                .isInstanceOf(ReservaNotFoundException.class);
    }

    // ── Reportes ─────────────────────────────────────────

    @Test
    @DisplayName("findByEstado() debe retornar reservas con el estado indicado")
    void findByEstado_retornaReservasFiltradas() {
        when(repository.findByEstado("PENDIENTE")).thenReturn(List.of(reserva));
        when(usuarioFeign.buscarUsuario(1L)).thenReturn(usuarioDTO);
        when(videojuegoFeign.buscarVideojuego(1L)).thenReturn(videojuegoDTO);

        List<ReservaDTO> resultado = service.findByEstado("PENDIENTE");

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getEstado()).isEqualTo("PENDIENTE");
    }

    @Test
    @DisplayName("findByUsuario() debe retornar reservas del usuario indicado")
    void findByUsuario_retornaReservasDelUsuario() {
        when(repository.findByUsuarioId(1L)).thenReturn(List.of(reserva));
        when(usuarioFeign.buscarUsuario(1L)).thenReturn(usuarioDTO);
        when(videojuegoFeign.buscarVideojuego(1L)).thenReturn(videojuegoDTO);

        List<ReservaDTO> resultado = service.findByUsuario(1L);

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getUsuario().getId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("findByVideojuego() debe retornar reservas del videojuego indicado")
    void findByVideojuego_retornaReservasDelVideojuego() {
        when(repository.findByVideojuegoId(1L)).thenReturn(List.of(reserva));
        when(usuarioFeign.buscarUsuario(1L)).thenReturn(usuarioDTO);
        when(videojuegoFeign.buscarVideojuego(1L)).thenReturn(videojuegoDTO);

        List<ReservaDTO> resultado = service.findByVideojuego(1L);

        assertThat(resultado).hasSize(1);
    }

    @Test
    @DisplayName("findByFechas() debe retornar reservas dentro del rango de fechas")
    void findByFechas_retornaReservasEnRango() {
        LocalDate desde = LocalDate.of(2025, 5, 1);
        LocalDate hasta = LocalDate.of(2025, 5, 31);

        when(repository.findByFechaReservaBetween(desde, hasta)).thenReturn(List.of(reserva));
        when(usuarioFeign.buscarUsuario(1L)).thenReturn(usuarioDTO);
        when(videojuegoFeign.buscarVideojuego(1L)).thenReturn(videojuegoDTO);

        List<ReservaDTO> resultado = service.findByFechas(desde, hasta);

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getFechaReserva()).isBetween(desde, hasta);
    }
}
