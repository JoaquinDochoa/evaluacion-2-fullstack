package cl.duoc.reservas_service.controller;

import cl.duoc.reservas_service.dto.ReservaDTO;
import cl.duoc.reservas_service.dto.UsuarioDTO;
import cl.duoc.reservas_service.dto.VideojuegoDTO;
import cl.duoc.reservas_service.exception.ReservaNotFoundException;
import cl.duoc.reservas_service.model.Reserva;
import cl.duoc.reservas_service.service.ReservaService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ReservaController.class)
@DisplayName("ReservaController - Pruebas unitarias")
class ReservaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReservaService service;

    private ObjectMapper objectMapper;

    private ReservaDTO reservaDTO;
    private Reserva reserva;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());

        UsuarioDTO usuarioDTO = UsuarioDTO.builder()
                .id(1L).nombre("Carlos Mendoza").rol("CLIENTE").build();

        VideojuegoDTO videojuegoDTO = VideojuegoDTO.builder()
                .id(1L).titulo("God of War").plataforma("PS5").precioArriendo(2500.0).build();

        reservaDTO = ReservaDTO.builder()
                .id(1L)
                .fechaReserva(LocalDate.of(2025, 5, 10))
                .estado("PENDIENTE")
                .usuario(usuarioDTO)
                .videojuego(videojuegoDTO)
                .build();

        reserva = Reserva.builder()
                .fechaReserva(LocalDate.of(2025, 5, 10))
                .estado("PENDIENTE")
                .usuarioId(1L)
                .videojuegoId(1L)
                .build();
    }

    // ── GET /api/v1/reservas ─────────────────────────────

    @Test
    @DisplayName("GET /api/v1/reservas debe retornar 200 con lista de reservas")
    void listar_retorna200ConLista() throws Exception {
        when(service.findAll()).thenReturn(List.of(reservaDTO));

        mockMvc.perform(get("/api/v1/reservas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].estado").value("PENDIENTE"))
                .andExpect(jsonPath("$[0].usuario.nombre").value("Carlos Mendoza"));
    }

    @Test
    @DisplayName("GET /api/v1/reservas debe retornar 200 con lista vacía")
    void listar_retorna200ListaVacia() throws Exception {
        when(service.findAll()).thenReturn(List.of());

        mockMvc.perform(get("/api/v1/reservas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    // ── GET /api/v1/reservas/{id} ────────────────────────

    @Test
    @DisplayName("GET /api/v1/reservas/{id} debe retornar 200 cuando existe")
    void buscar_retorna200CuandoExiste() throws Exception {
        when(service.findById(1L)).thenReturn(reservaDTO);

        mockMvc.perform(get("/api/v1/reservas/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.estado").value("PENDIENTE"))
                .andExpect(jsonPath("$.videojuego.titulo").value("God of War"));
    }

    @Test
    @DisplayName("GET /api/v1/reservas/{id} debe retornar 404 cuando no existe")
    void buscar_retorna404CuandoNoExiste() throws Exception {
        when(service.findById(99L)).thenThrow(new ReservaNotFoundException(99L));

        mockMvc.perform(get("/api/v1/reservas/99"))
                .andExpect(status().isNotFound());
    }

    // ── POST /api/v1/reservas ────────────────────────────

    @Test
    @DisplayName("POST /api/v1/reservas debe retornar 200 con reserva creada")
    void guardar_retorna200CuandoDatosValidos() throws Exception {
        when(service.save(any(Reserva.class))).thenReturn(reservaDTO);

        mockMvc.perform(post("/api/v1/reservas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(reserva)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("PENDIENTE"));
    }

    @Test
    @DisplayName("POST /api/v1/reservas debe retornar 400 cuando faltan campos")
    void guardar_retorna400CuandoCamposFaltantes() throws Exception {
        Reserva invalida = new Reserva(); // sin campos

        mockMvc.perform(post("/api/v1/reservas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalida)))
                .andExpect(status().isBadRequest());
    }

    // ── PUT /api/v1/reservas/{id} ────────────────────────

    @Test
    @DisplayName("PUT /api/v1/reservas/{id} debe retornar 200 con reserva actualizada")
    void actualizar_retorna200CuandoExiste() throws Exception {
        when(service.update(eq(1L), any(Reserva.class))).thenReturn(reservaDTO);

        mockMvc.perform(put("/api/v1/reservas/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(reserva)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    @DisplayName("PUT /api/v1/reservas/{id} debe retornar 404 cuando no existe")
    void actualizar_retorna404CuandoNoExiste() throws Exception {
        when(service.update(eq(99L), any(Reserva.class)))
                .thenThrow(new ReservaNotFoundException(99L));

        mockMvc.perform(put("/api/v1/reservas/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(reserva)))
                .andExpect(status().isNotFound());
    }

    // ── DELETE /api/v1/reservas/{id} ─────────────────────

    @Test
    @DisplayName("DELETE /api/v1/reservas/{id} debe retornar 204 cuando existe")
    void eliminar_retorna204CuandoExiste() throws Exception {
        doNothing().when(service).delete(1L);

        mockMvc.perform(delete("/api/v1/reservas/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("DELETE /api/v1/reservas/{id} debe retornar 404 cuando no existe")
    void eliminar_retorna404CuandoNoExiste() throws Exception {
        doThrow(new ReservaNotFoundException(99L)).when(service).delete(99L);

        mockMvc.perform(delete("/api/v1/reservas/99"))
                .andExpect(status().isNotFound());
    }

    // ── GET /api/v1/reservas/buscar/estado ───────────────

    @Test
    @DisplayName("GET /buscar/estado debe retornar 200 con reservas filtradas")
    void buscarPorEstado_retorna200() throws Exception {
        when(service.findByEstado("PENDIENTE")).thenReturn(List.of(reservaDTO));

        mockMvc.perform(get("/api/v1/reservas/buscar/estado")
                        .param("estado", "PENDIENTE"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].estado").value("PENDIENTE"));
    }

    // ── GET /api/v1/reservas/buscar/usuario ──────────────

    @Test
    @DisplayName("GET /buscar/usuario debe retornar 200 con reservas del usuario")
    void buscarPorUsuario_retorna200() throws Exception {
        when(service.findByUsuario(1L)).thenReturn(List.of(reservaDTO));

        mockMvc.perform(get("/api/v1/reservas/buscar/usuario")
                        .param("usuarioId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }

    // ── GET /api/v1/reservas/buscar/videojuego ───────────

    @Test
    @DisplayName("GET /buscar/videojuego debe retornar 200 con reservas del videojuego")
    void buscarPorVideojuego_retorna200() throws Exception {
        when(service.findByVideojuego(1L)).thenReturn(List.of(reservaDTO));

        mockMvc.perform(get("/api/v1/reservas/buscar/videojuego")
                        .param("videojuegoId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }

    // ── GET /api/v1/reservas/buscar/fechas ───────────────

    @Test
    @DisplayName("GET /buscar/fechas debe retornar 200 con reservas en el rango")
    void buscarPorFechas_retorna200() throws Exception {
        when(service.findByFechas(any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(List.of(reservaDTO));

        mockMvc.perform(get("/api/v1/reservas/buscar/fechas")
                        .param("desde", "2025-05-01")
                        .param("hasta", "2025-05-31"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }
}
