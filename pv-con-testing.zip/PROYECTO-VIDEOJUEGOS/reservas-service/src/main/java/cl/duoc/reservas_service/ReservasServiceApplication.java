package cl.duoc.reservas_service;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
@OpenAPIDefinition(
		info = @Info(
				title = "ARRIENDO DE VIDEOJUEGOS",
				description = "DESCRIPTION:" +
						"Documentación hecha por Benjamín Zuñiga",
				version = "1.0.1",
				contact = @Contact(
						name =
								"contact_name"
						,
						email = "benj.zunigam@duocuc.cl"
				)
		)
)
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class ReservasServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservasServiceApplication.class, args);
	}
}