package cl.duoc.reservas_service.controller;

import cl.duoc.reservas_service.dto.ReservaDTO;
import cl.duoc.reservas_service.exception.ErrorResponse;
import cl.duoc.reservas_service.model.Reserva;
import cl.duoc.reservas_service.service.ReservaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1/reservas")
@Tag(name = "Reservas", description = "Controlador para la gestión de reservas de videojuegos."+
    "Documentación Hecha por Benjamín Zuñiga")
public class ReservaController {

    @Autowired
    private ReservaService service;

    // ── CRUD ──────────────────────────────────────────────

    @GetMapping
    @Operation(
            summary = "Listar reservas",
            description = "Método para listar todas las reservas registradas en la base de datos."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado completo de reservas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = ReservaDTO.class)))
    )
    public ResponseEntity<List<ReservaDTO>> listar() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Buscar reserva por ID",
            description = "Método para buscar una reserva a través de su ID numérico."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Reserva encontrada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ReservaDTO.class))
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Reserva no encontrada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Solicitud mal enviada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<ReservaDTO> buscar(
            @PathVariable
            @Parameter(description = "ID de la reserva", example = "1", required = true)
            Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    @Operation(
            summary = "Registrar reserva",
            description = "Método para crear una nueva reserva. El estado debe ser PENDIENTE, CONFIRMADA o CANCELADA."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Reserva registrada correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ReservaDTO.class))
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos inválidos en la solicitud",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<ReservaDTO> guardar(@Valid @RequestBody Reserva reserva) {
        return ResponseEntity.ok(service.save(reserva));
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar reserva",
            description = "Método para actualizar los datos de una reserva existente."
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Reserva actualizada correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ReservaDTO.class))
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Reserva no encontrada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<ReservaDTO> actualizar(
            @PathVariable
            @Parameter(description = "ID de la reserva a actualizar", example = "1", required = true)
            Long id,
            @Valid @RequestBody Reserva reserva) {
        return ResponseEntity.ok(service.update(id, reserva));
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar reserva",
            description = "Método para eliminar una reserva del sistema por su ID."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Reserva eliminada correctamente"),
            @ApiResponse(
                    responseCode = "404",
                    description = "Reserva no encontrada",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ErrorResponse.class))
            )
    })
    public ResponseEntity<Void> eliminar(
            @PathVariable
            @Parameter(description = "ID de la reserva a eliminar", example = "1", required = true)
            Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // ── REPORTES ──────────────────────────────────────────

    @GetMapping("/buscar/estado")
    @Operation(
            summary = "Buscar reservas por estado",
            description = "Filtra reservas según su estado actual. Valores aceptados: PENDIENTE, CONFIRMADA, CANCELADA."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de reservas filtradas por estado",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = ReservaDTO.class)))
    )
    public ResponseEntity<List<ReservaDTO>> buscarPorEstado(
            @RequestParam
            @Parameter(description = "Estado de la reserva", example = "PENDIENTE", required = true)
            String estado) {
        return ResponseEntity.ok(service.findByEstado(estado));
    }

    @GetMapping("/buscar/usuario")
    @Operation(
            summary = "Buscar reservas por usuario",
            description = "Devuelve todas las reservas asociadas a un usuario específico."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de reservas del usuario",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = ReservaDTO.class)))
    )
    public ResponseEntity<List<ReservaDTO>> buscarPorUsuario(
            @RequestParam
            @Parameter(description = "ID del usuario", example = "2", required = true)
            Long usuarioId) {
        return ResponseEntity.ok(service.findByUsuario(usuarioId));
    }

    @GetMapping("/buscar/videojuego")
    @Operation(
            summary = "Buscar reservas por videojuego",
            description = "Devuelve todas las reservas asociadas a un videojuego específico."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de reservas del videojuego",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = ReservaDTO.class)))
    )
    public ResponseEntity<List<ReservaDTO>> buscarPorVideojuego(
            @RequestParam
            @Parameter(description = "ID del videojuego", example = "1", required = true)
            Long videojuegoId) {
        return ResponseEntity.ok(service.findByVideojuego(videojuegoId));
    }

    @GetMapping("/buscar/fechas")
    @Operation(
            summary = "Buscar reservas por rango de fechas",
            description = "Devuelve las reservas cuya fecha esté dentro del rango indicado. Formato: yyyy-MM-dd."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de reservas en el rango de fechas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = ReservaDTO.class)))
    )
    public ResponseEntity<List<ReservaDTO>> buscarPorFechas(
            @RequestParam
            @Parameter(description = "Fecha de inicio (yyyy-MM-dd)", example = "2025-05-01", required = true)
            LocalDate desde,
            @RequestParam
            @Parameter(description = "Fecha de fin (yyyy-MM-dd)", example = "2025-05-31", required = true)
            LocalDate hasta) {
        return ResponseEntity.ok(service.findByFechas(desde, hasta));
    }
}